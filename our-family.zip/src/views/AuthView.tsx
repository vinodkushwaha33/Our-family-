import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Shield,
  Smartphone,
  KeyRound,
  Users,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Lock,
} from 'lucide-react';

export const AuthView: React.FC = () => {
  const { loginWithPhone, createFamily, joinFamilyWithCode, isDemoMode } = useFamily();

  // Auth flow states: 'phone' -> 'otp' -> 'family_choice'
  const [step, setStep] = useState<'phone' | 'otp' | 'family_choice'>('phone');
  const [phone, setPhone] = useState('9876543210');
  const [otp, setOtp] = useState('123456');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Family registration / join states
  const [familyAction, setFamilyAction] = useState<'create' | 'join'>('create');
  const [familyName, setFamilyName] = useState('Sharma Parivar');
  const [familyMotto, setFamilyMotto] = useState('United by Love, Protected by Trust');
  const [inviteCode, setInviteCode] = useState('');

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!phone || phone.replace(/\D/g, '').length < 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }
    setLoading(true);
    // Simulate network delay
    setTimeout(() => {
      setLoading(false);
      setStep('otp');
    }, 600);
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const res = await loginWithPhone(phone, otp);
    setLoading(false);

    if (!res.success) {
      setError(res.error || 'Failed to verify OTP');
    }
    // If successfully logged in, context will update currentUser and redirect to app
  };

  const handleCreateFamily = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!familyName.trim()) {
      setError('Please enter a family name');
      return;
    }
    setLoading(true);
    const res = await createFamily(familyName, familyMotto);
    setLoading(false);
    if (!res.success) {
      setError(res.error || 'Failed to create family group');
    }
  };

  const handleJoinFamily = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) {
      setError('Please enter your Family Invite Code (e.g. FAM-84912)');
      return;
    }
    setLoading(true);
    const res = await joinFamilyWithCode(inviteCode);
    setLoading(false);
    if (!res.success) {
      setError(res.error || 'Invalid Family Invite Code');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Background Decorative Rings */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden relative z-10 animate-fade-in">
        {/* Brand Header */}
        <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 p-8 text-center text-white relative">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-lg mb-3">
            <Shield className="w-8 h-8 text-amber-300" />
          </div>
          <h1 className="text-2xl font-black tracking-tight">OUR FAMILY</h1>
          <p className="text-blue-200 text-xs mt-1 font-medium">
            The Digital Sanctuary for Indian Families
          </p>

          <div className="mt-4 inline-flex items-center gap-1.5 bg-white/15 px-3 py-1 rounded-full text-[11px] text-blue-100 font-semibold">
            <Lock className="w-3 h-3 text-emerald-300" />
            <span>End-to-End Encrypted Family Locker</span>
          </div>
        </div>

        {/* Form Container */}
        <div className="p-6 sm:p-8">
          {error && (
            <div className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {step === 'phone' && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Mobile Number
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-3 flex items-center gap-1 text-slate-500 font-bold text-sm border-r border-slate-200 pr-2">
                    <span>🇮🇳</span>
                    <span>+91</span>
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="98765 43210"
                    maxLength={10}
                    required
                    className="w-full pl-22 pr-4 py-3 rounded-xl border border-slate-200 text-slate-900 font-mono text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  We'll send a 6-digit OTP code to verify your family account.
                </p>
              </div>

              {/* Demo Helper Prompt */}
              {isDemoMode && (
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-800">
                  <p className="font-bold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Demo Mode Enabled:
                  </p>
                  <p className="mt-0.5 text-slate-600">
                    Use prefilled number or any 10-digit number. Test OTP is{' '}
                    <strong className="font-mono text-blue-700">123456</strong>.
                  </p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-700 hover:bg-blue-800 active:scale-[0.99] text-white py-3.5 rounded-xl font-bold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span>Sending OTP...</span>
                ) : (
                  <>
                    <span>Get Verification Code</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {step === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Enter 6-Digit OTP
                  </label>
                  <button
                    type="button"
                    onClick={() => setStep('phone')}
                    className="text-xs text-blue-600 font-semibold hover:underline"
                  >
                    Change Number
                  </button>
                </div>

                <input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456"
                  maxLength={6}
                  required
                  className="w-full text-center tracking-widest text-2xl font-mono font-bold py-3 rounded-xl border border-slate-200 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
                />
                <p className="text-[11px] text-slate-500 mt-1 text-center">
                  Sent to +91 {phone} (Test OTP: <span className="font-mono font-bold">123456</span>)
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-700 hover:bg-blue-800 active:scale-[0.99] text-white py-3.5 rounded-xl font-bold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? <span>Verifying...</span> : <span>Verify & Access Family Hub</span>}
              </button>

              <button
                type="button"
                onClick={() => setOtp('123456')}
                className="w-full text-center text-xs text-slate-500 hover:text-slate-800"
              >
                Auto-fill Demo Code (123456)
              </button>
            </form>
          )}

          {/* Security Guarantee Note */}
          <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-center gap-2 text-slate-400 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Strict privacy: Family data is never shared.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
