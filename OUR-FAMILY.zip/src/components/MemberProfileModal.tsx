import React from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  X,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  HeartPulse,
  AlertCircle,
  ShieldAlert,
  Calendar,
  FileText,
  Edit,
  FolderLock,
  ExternalLink,
} from 'lucide-react';

interface Props {
  onEdit?: () => void;
}

export const MemberProfileModal: React.FC<Props> = ({ onEdit }) => {
  const { selectedMemberProfile, setSelectedMemberProfile, documents, setActiveTab, hasPermission } = useFamily();

  if (!selectedMemberProfile) return null;

  const member = selectedMemberProfile;

  // Calculate age from DOB
  const calculateAge = (dobString: string) => {
    if (!dobString) return 'N/A';
    const dob = new Date(dobString);
    const diffMs = Date.now() - dob.getTime();
    const ageDt = new Date(diffMs);
    return Math.abs(ageDt.getUTCFullYear() - 1970);
  };

  const memberAge = calculateAge(member.dob);

  // Find documents tagged to this member
  const memberDocuments = documents.filter(
    (d) => d.memberId === member.id || d.memberId === 'family'
  );

  const cleanPhone = member.mobile.replace(/\D/g, '');
  const cleanEmergencyPhone = member.emergencyContactPhone?.replace(/\D/g, '') || '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6 animate-scale-in">
        {/* Header Cover Banner */}
        <div className="h-32 bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 relative">
          <button
            onClick={() => setSelectedMemberProfile(null)}
            className="absolute top-4 right-4 rounded-full p-2 bg-black/30 hover:bg-black/50 text-white backdrop-blur-sm transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Card Body */}
        <div className="px-6 pb-6 pt-0 relative">
          {/* Avatar & Key Identifiers */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-16 mb-4 gap-3">
            <div className="relative">
              <img
                src={member.avatarUrl}
                alt={member.fullName}
                className="w-28 h-28 rounded-2xl object-cover ring-4 ring-white shadow-lg bg-slate-100"
              />
              <span className="absolute -bottom-2 -right-2 bg-blue-700 text-white text-[11px] font-bold px-2 py-0.5 rounded-full border-2 border-white shadow-xs">
                {member.relationship}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Call Button */}
              {member.mobile && (
                <a
                  href={`tel:${member.mobile}`}
                  className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-sm transition active:scale-95"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call</span>
                </a>
              )}

              {/* WhatsApp Button */}
              {member.mobile && (
                <a
                  href={`https://wa.me/${cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`}?text=Namaste%20${encodeURIComponent(member.fullName)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-sm transition active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              )}

              {/* Edit button */}
              {onEdit && hasPermission('editOtherProfiles') && (
                <button
                  onClick={onEdit}
                  className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 transition"
                  title="Edit Member Information"
                >
                  <Edit className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Member Name and Blood Group */}
          <div className="mb-4">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-extrabold text-slate-900">{member.fullName}</h2>
              {member.bloodGroup && member.bloodGroup !== 'Unknown' && (
                <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 font-extrabold text-xs px-2.5 py-0.5 rounded-full border border-rose-200">
                  <HeartPulse className="w-3.5 h-3.5 text-rose-600" />
                  {member.bloodGroup} Blood
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {member.relationship} • {memberAge} years old ({member.gender})
            </p>
          </div>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
            {/* DOB */}
            <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
              <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Date of Birth</p>
                <p className="font-semibold text-slate-800">{member.dob || 'Not specified'}</p>
              </div>
            </div>

            {/* Mobile */}
            <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
              <Phone className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Mobile Number</p>
                <p className="font-semibold text-slate-800 font-mono">{member.mobile}</p>
              </div>
            </div>

            {/* Email */}
            {member.email && (
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs sm:col-span-2">
                <Mail className="w-4 h-4 text-indigo-600 shrink-0" />
                <div className="truncate">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Email Address</p>
                  <p className="font-semibold text-slate-800 truncate">{member.email}</p>
                </div>
              </div>
            )}

            {/* Address */}
            {member.address && (
              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs sm:col-span-2">
                <MapPin className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Residence Address</p>
                  <p className="font-medium text-slate-700 leading-relaxed">{member.address}</p>
                </div>
              </div>
            )}
          </div>

          {/* Emergency Contact & Medical Notes */}
          {(member.emergencyContactName || member.additionalInfo) && (
            <div className="mb-5 space-y-2">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>Emergency Contact & Medical Notes</span>
              </h4>

              <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2 text-xs">
                {member.emergencyContactName && (
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-amber-800">Primary Emergency Contact</p>
                      <p className="font-bold text-slate-900">{member.emergencyContactName}</p>
                      {member.emergencyContactPhone && (
                        <p className="text-[11px] font-mono text-slate-600">{member.emergencyContactPhone}</p>
                      )}
                    </div>
                    {member.emergencyContactPhone && (
                      <a
                        href={`tel:${member.emergencyContactPhone}`}
                        className="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1.5 rounded-xl font-bold flex items-center gap-1 text-[11px]"
                      >
                        <Phone className="w-3 h-3" /> Call
                      </a>
                    )}
                  </div>
                )}

                {member.additionalInfo && (
                  <div className="pt-2 border-t border-amber-200/60">
                    <p className="text-[10px] uppercase font-bold text-amber-800">Medical / Personal Notes</p>
                    <p className="text-slate-700 font-medium leading-relaxed mt-0.5">{member.additionalInfo}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Linked Documents in Locker */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <FolderLock className="w-3.5 h-3.5 text-blue-600" />
                <span>Linked Documents ({memberDocuments.length})</span>
              </h4>
              <button
                onClick={() => {
                  setSelectedMemberProfile(null);
                  setActiveTab('locker');
                }}
                className="text-[11px] font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
              >
                <span>View Locker</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            {memberDocuments.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-3 text-center bg-slate-50 rounded-xl">
                No documents uploaded for this member yet.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {memberDocuments.slice(0, 4).map((doc) => (
                  <div
                    key={doc.id}
                    className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-4 h-4 text-blue-700 shrink-0" />
                      <div className="truncate">
                        <p className="font-bold text-slate-800 text-xs truncate">{doc.title}</p>
                        <p className="text-[10px] text-slate-500 font-mono truncate">{doc.documentNumber || doc.category}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
