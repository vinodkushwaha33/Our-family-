import React, { useState } from 'react';
import { X, Key, ShieldCheck, Smartphone, Copy, Check, Download, ExternalLink, Code } from 'lucide-react';
import { useFamily } from '../context/FamilyContext';

interface Props {
  initialTab?: 'firebase' | 'rules' | 'android' | 'backup';
  onClose: () => void;
}

export const FirebaseSetupModal: React.FC<Props> = ({ initialTab = 'firebase', onClose }) => {
  const [activeTab, setActiveTab] = useState<'firebase' | 'rules' | 'android' | 'backup'>(initialTab);
  const [copiedEnv, setCopiedEnv] = useState(false);
  const [copiedRules, setCopiedRules] = useState(false);
  const { members, documents, contacts, reminders, currentFamily } = useFamily();

  const envSample = `# Add these to your .env file to enable live Firebase
VITE_FIREBASE_API_KEY="AIzaSyYourApiKeyHere"
VITE_FIREBASE_AUTH_DOMAIN="our-family-app.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="our-family-app"
VITE_FIREBASE_STORAGE_BUCKET="our-family-app.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="123456789012"
VITE_FIREBASE_APP_ID="1:123456789012:web:abcdef123456"`;

  const copyEnvText = () => {
    navigator.clipboard.writeText(envSample);
    setCopiedEnv(true);
    setTimeout(() => setCopiedEnv(false), 2000);
  };

  const exportBackupJson = () => {
    const backupData = {
      family: currentFamily,
      members,
      documents,
      contacts,
      reminders,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `our_family_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-base">Backend & Platform Configuration</h3>
              <p className="text-xs text-blue-200">Firebase setup, security architecture and Android packaging</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-blue-200 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2 gap-2 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('firebase')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'firebase'
                ? 'border-blue-700 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Key className="w-4 h-4" /> Firebase Credentials
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'rules'
                ? 'border-blue-700 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> Security Rules
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'android'
                ? 'border-blue-700 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smartphone className="w-4 h-4" /> Android App Guide
          </button>
          <button
            onClick={() => setActiveTab('backup')}
            className={`pb-2.5 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'backup'
                ? 'border-blue-700 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-4 h-4" /> Export Backup
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto space-y-4 text-sm text-slate-700">
          {activeTab === 'firebase' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-800">
                <strong>Status:</strong> The app is currently running in <strong>Demo Mode</strong> with comprehensive sample Indian family data. To switch to your live Firebase backend, add your Firebase keys to your environment.
              </div>

              <h4 className="font-bold text-slate-900 text-sm">Step-by-step Setup:</h4>
              <ol className="list-decimal list-inside space-y-2 text-xs text-slate-600">
                <li>Create a project at <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold inline-flex items-center gap-0.5">console.firebase.google.com <ExternalLink className="w-3 h-3" /></a></li>
                <li>In <strong>Authentication</strong> &gt; Sign-in method &gt; enable <strong>Phone</strong> authentication.</li>
                <li>In <strong>Cloud Firestore</strong> &gt; Create Database (Start in test mode or deploy the included <code>firestore.rules</code>).</li>
                <li>In <strong>Storage</strong> &gt; Create Storage bucket for photos & documents.</li>
                <li>In Project Settings &gt; General &gt; Add Web App &gt; Copy your config values into <code>.env</code>.</li>
              </ol>

              <div className="relative">
                <div className="flex items-center justify-between bg-slate-800 text-slate-200 px-3 py-1.5 rounded-t-lg text-xs font-mono">
                  <span>.env template</span>
                  <button
                    onClick={copyEnvText}
                    className="flex items-center gap-1 text-slate-300 hover:text-white transition"
                  >
                    {copiedEnv ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedEnv ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="bg-slate-900 text-slate-100 p-3 rounded-b-lg text-xs font-mono overflow-x-auto">
                  {envSample}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'rules' && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 text-sm">Strict Family Data Isolation:</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Security rules are pre-configured in <code>/firestore.rules</code> and <code>/storage.rules</code>. Every document, member, photo, and reminder is scoped under <code>/families/{'{familyId}'}</code>.
              </p>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-700 font-semibold">
                  <ShieldCheck className="w-4 h-4" /> Multi-Tenant Family Isolation
                </div>
                <p className="text-slate-600">
                  Users can strictly only query documents under their own family ID. Other families cannot read or enumerate records.
                </p>
                <div className="flex items-center gap-2 text-emerald-700 font-semibold pt-1">
                  <ShieldCheck className="w-4 h-4" /> Role & Permission Enforced
                </div>
                <p className="text-slate-600">
                  Document deletion and photo uploads are validated against the member's server-stored <code>permissions</code> object.
                </p>
                <div className="flex items-center gap-2 text-emerald-700 font-semibold pt-1">
                  <ShieldCheck className="w-4 h-4" /> Super Admin Privacy Boundary
                </div>
                <p className="text-slate-600">
                  Platform Super Admins can only view aggregate counts (total registered families, member counts) and have ZERO access to personal family locker files or private photos.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'android' && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 text-sm">Packaging as an Android Application:</h4>
              <p className="text-xs text-slate-600">
                This project is built as a responsive, PWA-compliant web app that can be installed directly from mobile browsers or packaged as a native Android APK using <strong>Capacitor</strong>.
              </p>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
                  <h5 className="font-bold text-blue-900 mb-1">Option 1: Instant PWA Install (No APK build needed)</h5>
                  <p className="text-blue-800">
                    Open the app URL in Chrome on any Android phone, tap the <strong>"Install App"</strong> button in the header (or Chrome menu &gt; "Add to Home Screen"). The app installs with standalone app icon, splash screen, and offline capabilities.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <h5 className="font-bold text-slate-900">Option 2: Native Android APK with Capacitor</h5>
                  <p className="text-slate-600">Run the following commands in your local project folder:</p>
                  <pre className="bg-slate-900 text-slate-100 p-2.5 rounded-lg font-mono text-[11px] overflow-x-auto">
{`npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Our Family" "com.ourfamily.app" --web-dir dist
npm run build
npx cap add android
npx cap open android`}
                  </pre>
                  <p className="text-slate-500 text-[11px]">
                    This opens Android Studio where you can click <strong>Build &gt; Build APK(s)</strong> or generate a signed bundle for the Google Play Store.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 text-sm">Backup Your Family Records:</h4>
              <p className="text-xs text-slate-600">
                Export all family members, locker metadata, emergency contacts, gallery albums, and reminders as a secure JSON backup file.
              </p>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <p className="font-semibold text-slate-800 text-xs">Active Family: {currentFamily?.name}</p>
                  <p className="text-slate-500 text-[11px]">{members.length} members • {documents.length} documents • {contacts.length} contacts</p>
                </div>
                <button
                  onClick={exportBackupJson}
                  className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white px-3.5 py-2 rounded-xl text-xs font-semibold shadow-sm transition active:scale-95 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Backup JSON</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 px-4 py-2 text-xs font-semibold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
