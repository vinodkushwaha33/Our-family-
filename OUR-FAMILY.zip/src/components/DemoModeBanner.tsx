import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import { ShieldAlert, Database, Info, RefreshCw, KeyRound, Smartphone } from 'lucide-react';
import { FirebaseSetupModal } from './FirebaseSetupModal';

export const DemoModeBanner: React.FC = () => {
  const { isDemoMode, resetDemoData, currentUser, switchUserRole } = useFamily();
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [showAndroidTab, setShowAndroidTab] = useState(false);

  if (!isDemoMode) {
    return (
      <div className="bg-emerald-600 text-white px-4 py-1.5 text-xs font-medium flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-3.5 h-3.5" />
          <span>Connected to Live Firebase (Cloud Firestore & Storage)</span>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 text-white px-3 sm:px-4 py-2 text-xs border-b border-blue-800 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="inline-flex items-center gap-1 bg-amber-400 text-amber-950 font-bold px-2 py-0.5 rounded-full text-[10px] tracking-wide uppercase">
              <ShieldAlert className="w-3 h-3" /> Demo Mode
            </span>
            <span className="text-blue-100">
              Running with sample data. Sensitive documents remain locally simulated.
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-center">
            {/* Quick role toggle to test Admin vs Member vs Super Admin */}
            <div className="flex items-center gap-1 bg-white/10 px-2 py-1 rounded-lg text-[11px]">
              <span className="text-blue-200">Role:</span>
              <button
                onClick={() => switchUserRole('admin')}
                className={`px-1.5 py-0.5 rounded transition ${
                  currentUser?.role === 'admin'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-blue-200 hover:text-white'
                }`}
              >
                Admin
              </button>
              <button
                onClick={() => switchUserRole('member')}
                className={`px-1.5 py-0.5 rounded transition ${
                  currentUser?.role === 'member'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-blue-200 hover:text-white'
                }`}
              >
                Member
              </button>
              <button
                onClick={() => switchUserRole('superadmin')}
                className={`px-1.5 py-0.5 rounded transition ${
                  currentUser?.role === 'superadmin'
                    ? 'bg-purple-600 text-white font-bold'
                    : 'text-blue-200 hover:text-white'
                }`}
              >
                SuperAdmin
              </button>
            </div>

            <button
              onClick={() => {
                setShowAndroidTab(false);
                setShowConfigModal(true);
              }}
              className="flex items-center gap-1 bg-blue-700 hover:bg-blue-600 text-white px-2.5 py-1 rounded-lg font-medium transition cursor-pointer"
            >
              <KeyRound className="w-3 h-3" />
              <span>Connect Firebase</span>
            </button>

            <button
              onClick={() => {
                setShowAndroidTab(true);
                setShowConfigModal(true);
              }}
              className="flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 text-white px-2.5 py-1 rounded-lg font-medium transition cursor-pointer"
            >
              <Smartphone className="w-3 h-3" />
              <span>Android Guide</span>
            </button>

            <button
              onClick={resetDemoData}
              title="Reset to fresh demo sample data"
              className="flex items-center gap-1 text-blue-200 hover:text-white bg-white/5 hover:bg-white/15 px-2 py-1 rounded-lg transition cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span className="hidden md:inline">Reset Data</span>
            </button>
          </div>
        </div>
      </div>

      {showConfigModal && (
        <FirebaseSetupModal
          initialTab={showAndroidTab ? 'android' : 'firebase'}
          onClose={() => setShowConfigModal(false)}
        />
      )}
    </>
  );
};
