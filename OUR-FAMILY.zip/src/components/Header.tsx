import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Shield,
  Copy,
  Check,
  PhoneCall,
  LogOut,
  User,
  Settings,
  Menu,
  Sparkles,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const { currentFamily, currentUser, logout, setActiveTab, activeTab } = useFamily();
  const [copiedCode, setCopiedCode] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const copyFamilyCode = () => {
    if (!currentFamily?.familyCode) return;
    navigator.clipboard.writeText(currentFamily.familyCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Brand & Family Name */}
        <div className="flex items-center gap-3">
          {onToggleMobileMenu && (
            <button
              onClick={onToggleMobileMenu}
              className="md:hidden p-2 -ml-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-900 via-blue-700 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition">
              <Shield className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-slate-900 tracking-tight text-base sm:text-lg">
                  OUR FAMILY
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                  Hub
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium truncate max-w-[140px] sm:max-w-[220px]">
                {currentFamily?.name || 'My Family'}
              </p>
            </div>
          </div>

          {/* Family ID Badge with quick copy */}
          {currentFamily?.familyCode && (
            <button
              onClick={copyFamilyCode}
              title="Click to copy unique Family ID"
              className="hidden sm:flex items-center gap-1.5 bg-slate-100 hover:bg-blue-50 hover:border-blue-300 border border-slate-200 text-slate-700 hover:text-blue-700 px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition cursor-pointer"
            >
              <span className="text-slate-400 text-[10px] uppercase font-sans font-bold">ID:</span>
              <span>{currentFamily.familyCode}</span>
              {copiedCode ? (
                <Check className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-slate-400" />
              )}
            </button>
          )}
        </div>

        {/* Right: Actions, PWA Button, Emergency, User Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* In-App Install Prompt */}
          <PWAInstallButton />

          {/* Emergency Hotline Button */}
          <button
            onClick={() => setActiveTab('contacts')}
            className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer shadow-xs"
            title="View Emergency Directory (108, 112, Doctors)"
          >
            <PhoneCall className="w-3.5 h-3.5 animate-pulse text-rose-600" />
            <span className="hidden sm:inline">Emergency</span>
          </button>

          {/* User Profile / Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition cursor-pointer"
            >
              <img
                src={currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                alt={currentUser?.name || 'User'}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-blue-600/30"
              />
              <div className="hidden lg:block text-left text-xs">
                <p className="font-bold text-slate-800 leading-tight truncate max-w-[100px]">
                  {currentUser?.name || 'Family User'}
                </p>
                <p className="text-[10px] text-blue-700 font-semibold uppercase tracking-wider">
                  {currentUser?.role || 'Member'}
                </p>
              </div>
            </button>

            {/* Dropdown Menu */}
            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white shadow-xl border border-slate-100 py-2 z-50 text-xs">
                <div className="px-4 py-2 border-b border-slate-100">
                  <p className="font-bold text-slate-900 text-sm truncate">{currentUser?.name}</p>
                  <p className="text-slate-500 text-[11px] font-mono">{currentUser?.phone}</p>
                  <div className="mt-1 flex items-center gap-1 text-[10px] text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded-md w-fit">
                    <Sparkles className="w-3 h-3" /> {currentUser?.role === 'admin' ? 'Family Administrator' : currentUser?.role === 'superadmin' ? 'Platform Super Admin' : 'Family Member'}
                  </div>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      setActiveTab('admin');
                      setShowUserDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-medium"
                  >
                    <Settings className="w-4 h-4 text-slate-400" />
                    <span>Family Settings & Permissions</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('superadmin');
                      setShowUserDropdown(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-medium"
                  >
                    <Shield className="w-4 h-4 text-slate-400" />
                    <span>Super Admin Overview</span>
                  </button>
                </div>

                <div className="border-t border-slate-100 pt-1">
                  <button
                    onClick={() => {
                      setShowUserDropdown(false);
                      logout();
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-rose-50 text-rose-600 flex items-center gap-2 font-semibold"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Log Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
