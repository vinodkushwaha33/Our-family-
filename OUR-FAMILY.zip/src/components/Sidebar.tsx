import React from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  LayoutDashboard,
  Users,
  FolderLock,
  Image as ImageIcon,
  PhoneCall,
  BellRing,
  ShieldCheck,
  Globe2,
  Share2,
} from 'lucide-react';

interface SidebarProps {
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onCloseMobile }) => {
  const { activeTab, setActiveTab, currentUser, members, documents, allComputedReminders, currentFamily } = useFamily();

  const uncompletedRemindersCount = allComputedReminders.filter((r) => !r.completed).length;

  const navItems = [
    {
      id: 'dashboard',
      label: 'Family Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'members',
      label: 'Family Members',
      icon: Users,
      badge: members.length,
    },
    {
      id: 'locker',
      label: 'Digital Locker',
      icon: FolderLock,
      badge: documents.length,
    },
    {
      id: 'gallery',
      label: 'Photo Gallery',
      icon: ImageIcon,
      badge: null,
    },
    {
      id: 'contacts',
      label: 'Important Contacts',
      icon: PhoneCall,
      badge: null,
    },
    {
      id: 'reminders',
      label: 'Reminders & Events',
      icon: BellRing,
      badge: uncompletedRemindersCount > 0 ? uncompletedRemindersCount : null,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      id: 'admin',
      label: 'Family Admin Panel',
      icon: ShieldCheck,
      badge: currentUser?.role === 'admin' ? 'Admin' : null,
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    {
      id: 'superadmin',
      label: 'Platform Overview',
      icon: Globe2,
      badge: 'Owner',
      badgeColor: 'bg-purple-100 text-purple-800',
    },
  ];

  const handleSelect = (id: string) => {
    setActiveTab(id);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col justify-between h-full shrink-0">
      <div className="p-4 space-y-6">
        {/* Family Greeting Card in Sidebar */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 text-white shadow-md relative overflow-hidden">
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-white/5 rounded-full blur-xl"></div>
          <div className="relative z-10">
            <span className="text-[10px] uppercase font-bold tracking-wider text-blue-200">
              Active Group
            </span>
            <h4 className="font-extrabold text-sm truncate text-white mt-0.5">
              {currentFamily?.name || 'Our Family'}
            </h4>
            <p className="text-[11px] text-blue-200 line-clamp-1 mt-0.5 italic">
              "{currentFamily?.motto || 'United with Love'}"
            </p>

            <div className="mt-3 pt-2.5 border-t border-white/15 flex items-center justify-between text-[11px]">
              <span className="text-blue-200">Invite Code:</span>
              <span className="font-mono font-bold bg-white/20 px-2 py-0.5 rounded text-white text-[11px]">
                {currentFamily?.familyCode}
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition active:scale-[0.99] cursor-pointer ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 shadow-xs border border-blue-200/60 font-bold'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition ${
                      isActive ? 'text-blue-700' : 'text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge !== null && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      item.badgeColor || (isActive ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600')
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer helper */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50 text-[11px] text-slate-500">
        <div className="flex items-center justify-between text-slate-400">
          <span>OUR FAMILY v1.0</span>
          <span className="flex items-center gap-1 text-emerald-600 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Encrypted
          </span>
        </div>
      </div>
    </aside>
  );
};
