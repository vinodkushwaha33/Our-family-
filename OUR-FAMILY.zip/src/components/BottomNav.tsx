import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  LayoutDashboard,
  Users,
  FolderLock,
  Image as ImageIcon,
  MoreHorizontal,
  PhoneCall,
  BellRing,
  ShieldCheck,
  Globe2,
  X,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, allComputedReminders } = useFamily();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  const pendingReminders = allComputedReminders.filter((r) => !r.completed).length;

  const mainItems = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'locker', label: 'Locker', icon: FolderLock },
    { id: 'gallery', label: 'Gallery', icon: ImageIcon },
  ];

  const moreItems = [
    { id: 'contacts', label: 'Important Contacts & 108', icon: PhoneCall, color: 'text-rose-600' },
    {
      id: 'reminders',
      label: `Reminders & Events ${pendingReminders > 0 ? `(${pendingReminders})` : ''}`,
      icon: BellRing,
      color: 'text-amber-600',
    },
    { id: 'admin', label: 'Family Admin & Permissions', icon: ShieldCheck, color: 'text-blue-600' },
    { id: 'superadmin', label: 'Platform Overview', icon: Globe2, color: 'text-purple-600' },
  ];

  return (
    <>
      {/* "More" Drawer / Modal for Mobile */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end md:hidden animate-fade-in">
          <div
            className="fixed inset-0"
            onClick={() => setShowMoreMenu(false)}
          />
          <div className="relative bg-white rounded-t-3xl p-5 shadow-2xl border-t border-slate-200 space-y-3 z-10 animate-slide-up">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">More Family Tools</h3>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700 bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-2 pt-1">
              {moreItems.map((item) => {
                const Icon = item.icon;
                const isCurrent = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setShowMoreMenu(false);
                    }}
                    className={`flex items-center gap-3 p-3 rounded-2xl text-xs font-bold transition text-left ${
                      isCurrent
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className={`p-2 rounded-xl bg-white shadow-xs ${item.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg px-2 py-1">
        <div className="flex items-center justify-around max-w-lg mx-auto">
          {mainItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setShowMoreMenu(false);
                  setActiveTab(item.id);
                }}
                className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition cursor-pointer active:scale-95 ${
                  isActive ? 'text-blue-700 font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-5 h-5 transition ${isActive ? 'scale-110 text-blue-700' : ''}`} />
                <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
                {isActive && <span className="w-1 h-1 rounded-full bg-blue-700 mt-0.5" />}
              </button>
            );
          })}

          {/* More Button */}
          <button
            onClick={() => setShowMoreMenu(true)}
            className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition cursor-pointer active:scale-95 ${
              ['contacts', 'reminders', 'admin', 'superadmin'].includes(activeTab)
                ? 'text-blue-700 font-bold'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className="relative">
              <MoreHorizontal className="w-5 h-5" />
              {pendingReminders > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-500" />
              )}
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight">More</span>
            {['contacts', 'reminders', 'admin', 'superadmin'].includes(activeTab) && (
              <span className="w-1 h-1 rounded-full bg-blue-700 mt-0.5" />
            )}
          </button>
        </div>
      </nav>
    </>
  );
};
