import React from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Globe2,
  Users,
  ShieldAlert,
  FolderLock,
  TrendingUp,
  Building,
  CheckCircle2,
  Lock,
  ShieldCheck,
  Server,
  Activity,
  HardDrive,
} from 'lucide-react';

export const SuperAdminView: React.FC = () => {
  const { superAdminStats, currentFamily, members, documents } = useFamily();

  const mockFamilyRegistry = [
    {
      id: 'fam_01',
      code: 'FAM-84912',
      name: currentFamily?.name || 'Sharma Parivar',
      city: 'Jaipur, RJ',
      members: members.length,
      admin: currentFamily?.adminName || 'Rajesh Sharma',
      status: 'Active',
      joined: '15 Jan 2024',
    },
    {
      id: 'fam_02',
      code: 'FAM-61290',
      name: 'Verma Niwas',
      city: 'Lucknow, UP',
      members: 7,
      admin: 'Sunil Verma',
      status: 'Active',
      joined: '02 Feb 2024',
    },
    {
      id: 'fam_03',
      code: 'FAM-49102',
      name: 'Kushwaha Family',
      city: 'Varanasi, UP',
      members: 5,
      admin: 'Vinod Kushwaha',
      status: 'Active',
      joined: '10 Feb 2024',
    },
    {
      id: 'fam_04',
      code: 'FAM-38192',
      name: 'Deshmukh Parivar',
      city: 'Pune, MH',
      members: 8,
      admin: 'Rohan Deshmukh',
      status: 'Active',
      joined: '22 Feb 2024',
    },
    {
      id: 'fam_05',
      code: 'FAM-99412',
      name: 'Gupta & Sons Hub',
      city: 'New Delhi, DL',
      members: 6,
      admin: 'Anil Gupta',
      status: 'Active',
      joined: '01 Mar 2024',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Globe2 className="w-6 h-6 text-purple-600" />
            <span>Platform Super Admin Dashboard</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Platform-wide telemetry, multi-tenant growth metrics, and aggregate server health.
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-full text-xs font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>System All Operational</span>
        </div>
      </div>

      {/* STRICT PRIVACY BOUNDARY NOTICE */}
      <div className="rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-start gap-4 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/20">
            <Lock className="w-6 h-6 text-amber-300" />
          </div>
          <div className="space-y-1">
            <h2 className="font-extrabold text-base text-white flex items-center gap-2">
              <span>Strict Zero-Knowledge Family Privacy Boundary</span>
              <span className="text-[10px] uppercase font-bold tracking-wider bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full">
                Enforced
              </span>
            </h2>
            <p className="text-xs text-purple-200 leading-relaxed max-w-3xl">
              By architectural design and Firestore security rules, platform super administrators can only view aggregated platform metrics and anonymized registration statistics. <strong>Platform staff cannot inspect, preview, or download private family Aadhaar cards, PAN cards, property deeds, or family gallery albums.</strong>
            </p>
          </div>
        </div>
      </div>

      {/* METRIC CARDS GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Total Families */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-purple-600">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Families
            </span>
            <Building className="w-4 h-4" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {superAdminStats.totalFamilies.toLocaleString()}
          </p>
          <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+{superAdminStats.newFamiliesThisMonth} this month</span>
          </div>
        </div>

        {/* Total Members */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-blue-600">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Members
            </span>
            <Users className="w-4 h-4" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {superAdminStats.totalMembers.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-medium">Avg 5.4 members / family</p>
        </div>

        {/* New Today */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-amber-600">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              New Families Today
            </span>
            <Activity className="w-4 h-4" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            +{superAdminStats.newFamiliesToday}
          </p>
          <p className="text-[11px] text-emerald-600 font-bold">100% Verified OTP</p>
        </div>

        {/* Active Families */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-emerald-600">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Families (30d)
            </span>
            <ShieldCheck className="w-4 h-4" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {superAdminStats.activeFamilies.toLocaleString()}
          </p>
          <p className="text-[11px] text-slate-500 font-medium">90.4% Retention Rate</p>
        </div>
      </div>

      {/* STORAGE & REPOSITORY METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-3xl p-5 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Documents Vault Stored</span>
            <FolderLock className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-slate-900">{superAdminStats.totalDocuments.toLocaleString()} items</p>
          <p className="text-[11px] text-slate-500">Aadhaar, PAN, Passports & Policies</p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Family Photo Memories</span>
            <Server className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-2xl font-black text-slate-900">{superAdminStats.totalPhotos.toLocaleString()} memories</p>
          <p className="text-[11px] text-slate-500">Compressed & geo-replicated</p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200 space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Encrypted Cloud Storage</span>
            <HardDrive className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-slate-900">{(superAdminStats.storageUsedMb / 1024).toFixed(1)} GB</p>
          <p className="text-[11px] text-slate-500">Firebase Storage Bucket</p>
        </div>
      </div>

      {/* RECENT REGISTERED FAMILIES DIRECTORY (METADATA ONLY) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">Registered Family Circles (Overview)</h3>
            <p className="text-xs text-slate-500">High-level registry metadata without access to personal documents</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                <th className="pb-3 pl-2">Family Code</th>
                <th className="pb-3">Family Group Name</th>
                <th className="pb-3">Location</th>
                <th className="pb-3">Administrator</th>
                <th className="pb-3 text-center">Members</th>
                <th className="pb-3">Registered On</th>
                <th className="pb-3 pr-2 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {mockFamilyRegistry.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 pl-2 font-mono font-bold text-blue-700">{item.code}</td>
                  <td className="py-3 font-bold text-slate-900">{item.name}</td>
                  <td className="py-3 text-slate-500">{item.city}</td>
                  <td className="py-3 text-slate-800">{item.admin}</td>
                  <td className="py-3 text-center">
                    <span className="bg-blue-50 text-blue-800 font-bold px-2 py-0.5 rounded-md text-[11px]">
                      {item.members}
                    </span>
                  </td>
                  <td className="py-3 text-slate-500">{item.joined}</td>
                  <td className="py-3 pr-2 text-right">
                    <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full text-[10px] border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3" /> {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
