import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  ShieldCheck,
  Settings,
  Users,
  Lock,
  Share2,
  Copy,
  Check,
  Palette,
  AlertTriangle,
  Sliders,
  Sparkles,
  Save,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { MemberPermissions } from '../types';
import {
  DEFAULT_ADMIN_PERMISSIONS,
  DEFAULT_MEMBER_PERMISSIONS,
  DEFAULT_VIEWER_PERMISSIONS,
} from '../data/mockData';

export const AdminPanelView: React.FC = () => {
  const {
    currentFamily,
    updateFamilySettings,
    members,
    updateMemberPermissions,
    currentUser,
    setActiveTab,
  } = useFamily();

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Selected member for permission matrix inspection
  const [selectedMemberId, setSelectedMemberId] = useState<string>(
    members[0]?.id || ''
  );

  // Form states for family settings
  const [familyForm, setFamilyForm] = useState({
    name: currentFamily?.name || '',
    motto: currentFamily?.motto || '',
    emergencyNotice: currentFamily?.emergencyNotice || '',
    themeColor: currentFamily?.themeColor || 'royal-blue',
  });

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateFamilySettings(familyForm as any);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const selectedMember = members.find((m) => m.id === selectedMemberId);

  const handleTogglePermission = (key: keyof MemberPermissions) => {
    if (!selectedMember) return;
    const currentVal = selectedMember.permissions[key];
    const newPermissions = {
      ...selectedMember.permissions,
      [key]: !currentVal,
    };
    updateMemberPermissions(selectedMember.id, newPermissions);
  };

  const handleApplyPreset = (preset: 'admin' | 'standard' | 'viewer') => {
    if (!selectedMember) return;
    let target = DEFAULT_MEMBER_PERMISSIONS;
    if (preset === 'admin') target = DEFAULT_ADMIN_PERMISSIONS;
    if (preset === 'viewer') target = DEFAULT_VIEWER_PERMISSIONS;
    updateMemberPermissions(selectedMember.id, target);
  };

  const copyCodeOnly = () => {
    if (!currentFamily?.familyCode) return;
    navigator.clipboard.writeText(currentFamily.familyCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyFullInvite = () => {
    if (!currentFamily) return;
    const text = `Namaste! Join our family on "OUR FAMILY - Digital Family Hub".\nFamily Group: ${currentFamily.name}\nInvite Code: ${currentFamily.familyCode}\nAccess all family identity proofs, medical records, and gallery here: ${window.location.origin}`;
    navigator.clipboard.writeText(text);
    setCopiedInvite(true);
    setTimeout(() => setCopiedInvite(false), 2000);
  };

  const PERMISSION_DEFINITIONS: { key: keyof MemberPermissions; label: string; desc: string }[] = [
    { key: 'viewFamily', label: 'View Family Details', desc: 'Can see family overview and member directory' },
    { key: 'viewDocs', label: 'View Documents', desc: 'Can open and view Aadhaar, PAN, and insurance cards in locker' },
    { key: 'uploadDocs', label: 'Upload Documents', desc: 'Can add scanned documents, certificates, and policies' },
    { key: 'downloadDocs', label: 'Download Documents', desc: 'Can download PDF and JPG files to local device' },
    { key: 'deleteDocs', label: 'Delete Documents', desc: 'Can remove files from the digital locker' },
    { key: 'viewGallery', label: 'View Gallery', desc: 'Can browse family memories and albums' },
    { key: 'uploadPhotos', label: 'Upload Photos', desc: 'Can upload pictures to albums and tag family members' },
    { key: 'editOwnProfile', label: 'Edit Own Profile', desc: 'Can modify their own contact info, address, and photo' },
    { key: 'editOtherProfiles', label: 'Edit Other Profiles', desc: 'Can modify other family members or add new members' },
    { key: 'manageContacts', label: 'Manage Contacts', desc: 'Can add, edit, or delete emergency & doctor contacts' },
    { key: 'manageReminders', label: 'Manage Reminders', desc: 'Can create and delete family calendar events' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-blue-700" />
            <span>Family Administrator Panel</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Control family group settings, generate invite codes, and manage granular permissions per member.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-200 px-3.5 py-2 rounded-2xl text-xs font-bold animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Settings Saved Successfully!</span>
          </div>
        )}
      </div>

      {/* SECTION 1: UNIQUE FAMILY ID & INVITE CARD */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="max-w-2xl relative z-10 space-y-4">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-amber-300" />
            <h2 className="font-extrabold text-base sm:text-lg">Invite Family Members to Your Group</h2>
          </div>
          <p className="text-xs sm:text-sm text-blue-200 leading-relaxed">
            Every family created in OUR FAMILY has an isolated database ID. Share this code with your spouse, children, or parents so they can securely join:
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/20 flex items-center justify-between gap-4 font-mono font-black text-xl text-amber-300 tracking-wider">
              <span>{currentFamily?.familyCode}</span>
              <button
                onClick={copyCodeOnly}
                className="p-1 rounded-lg hover:bg-white/10 text-white transition cursor-pointer"
                title="Copy Code"
              >
                {copiedCode ? <Check className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>

            <button
              onClick={copyFullInvite}
              className="flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-300 text-amber-950 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm shadow-md transition active:scale-95 cursor-pointer"
            >
              {copiedInvite ? <Check className="w-4 h-4 text-emerald-800" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedInvite ? 'Invite Copied!' : 'Copy WhatsApp Invite Message'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 2: GRANULAR CUSTOM PERMISSIONS MATRIX */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-5">
        <div>
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-blue-700" />
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Granular Member Permissions (RBAC)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Admin can individually toggle access for every family member. Changes take effect instantly.
          </p>
        </div>

        {/* Member Selector Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {members.map((m) => {
            const isSelected = m.id === selectedMemberId;
            return (
              <button
                key={m.id}
                onClick={() => setSelectedMemberId(m.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-semibold shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-blue-50 border-blue-600 text-blue-900 ring-2 ring-blue-600/20'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <img
                  src={m.avatarUrl}
                  alt={m.fullName}
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span>{m.fullName}</span>
                <span className="text-[10px] text-slate-400">({m.relationship})</span>
              </button>
            );
          })}
        </div>

        {/* Selected Member Preset & Permission Matrix Table */}
        {selectedMember && (
          <div className="border border-slate-200 rounded-2xl overflow-hidden space-y-4 p-4 sm:p-5 bg-slate-50/50">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div className="flex items-center gap-3">
                <img
                  src={selectedMember.avatarUrl}
                  alt={selectedMember.fullName}
                  className="w-12 h-12 rounded-xl object-cover ring-2 ring-blue-600"
                />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{selectedMember.fullName}</h3>
                  <p className="text-xs text-slate-500">
                    Role: {selectedMember.relationship === 'Self' ? 'Family Administrator' : selectedMember.relationship} • {selectedMember.mobile}
                  </p>
                </div>
              </div>

              {/* Quick Presets */}
              <div className="flex items-center gap-1.5 self-start sm:self-auto">
                <span className="text-[11px] text-slate-500 font-semibold mr-1">Apply Preset:</span>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('admin')}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-blue-100 text-blue-800 hover:bg-blue-200 transition"
                >
                  Full Admin
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('standard')}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-200 text-slate-800 hover:bg-slate-300 transition"
                >
                  Standard
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('viewer')}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-100 text-amber-800 hover:bg-amber-200 transition"
                >
                  Viewer Only
                </button>
              </div>
            </div>

            {/* 11 Permission Items Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {PERMISSION_DEFINITIONS.map(({ key, label, desc }) => {
                const isEnabled = selectedMember.permissions[key];
                return (
                  <div
                    key={key}
                    onClick={() => handleTogglePermission(key)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                      isEnabled
                        ? 'bg-blue-50/70 border-blue-200 text-blue-950'
                        : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <p className={`font-bold text-xs ${isEnabled ? 'text-blue-950' : 'text-slate-800'}`}>
                        {label}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">{desc}</p>
                    </div>

                    <div
                      className={`w-10 h-6 flex items-center rounded-full p-1 transition shrink-0 ${
                        isEnabled ? 'bg-blue-700 justify-end' : 'bg-slate-300 justify-start'
                      }`}
                    >
                      <span className="bg-white w-4 h-4 rounded-full shadow-md" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 3: FAMILY BRANDING & THEME CUSTOMIZATION */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Palette className="w-5 h-5 text-blue-700" />
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            Family Branding & Customization
          </h2>
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Family Group Name *
              </label>
              <input
                type="text"
                required
                value={familyForm.name}
                onChange={(e) => setFamilyForm({ ...familyForm, name: e.target.value })}
                placeholder="e.g. Sharma Parivar or Kushwaha Family"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Family Motto / Tagline
              </label>
              <input
                type="text"
                value={familyForm.motto}
                onChange={(e) => setFamilyForm({ ...familyForm, motto: e.target.value })}
                placeholder="e.g. United by Love, Protected by Trust"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Emergency Notice / Family Announcement (Broadcast on Dashboard)
            </label>
            <input
              type="text"
              value={familyForm.emergencyNotice}
              onChange={(e) => setFamilyForm({ ...familyForm, emergencyNotice: e.target.value })}
              placeholder="e.g. Grandpa has a regular checkup scheduled this Thursday at Apollo Clinic"
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>

          {/* Theme Color Selector */}
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Royal Accent Theme
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {[
                { id: 'royal-blue', name: 'Royal Blue (Classic)', bg: 'bg-blue-700' },
                { id: 'indigo', name: 'Imperial Indigo', bg: 'bg-indigo-700' },
                { id: 'emerald', name: 'Emerald Heritage', bg: 'bg-emerald-700' },
                { id: 'crimson', name: 'Royal Crimson', bg: 'bg-rose-700' },
                { id: 'sapphire', name: 'Deep Sapphire', bg: 'bg-cyan-800' },
              ].map((theme) => (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => setFamilyForm({ ...familyForm, themeColor: theme.id as any })}
                  className={`p-3 rounded-2xl border text-left flex items-center gap-2 transition ${
                    familyForm.themeColor === theme.id
                      ? 'border-blue-700 bg-blue-50 ring-2 ring-blue-700/20 font-bold'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full ${theme.bg} shrink-0 shadow-xs`} />
                  <span className="text-xs truncate">{theme.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Family Configuration</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
