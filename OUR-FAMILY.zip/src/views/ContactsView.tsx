import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  PhoneCall,
  Plus,
  Search,
  Filter,
  Phone,
  MessageCircle,
  MapPin,
  Mail,
  Trash2,
  Edit,
  X,
  ShieldAlert,
  Building,
  HeartPulse,
  UserCheck,
  Building2,
  LifeBuoy,
} from 'lucide-react';
import { ImportantContact, ContactCategory } from '../types';

export const CONTACT_CATEGORIES: ContactCategory[] = [
  'Family Relatives',
  'Doctors',
  'Hospitals',
  'Ambulance',
  'Police',
  'Bank',
  'Emergency Helpline',
  'Other Contacts',
];

export const ContactsView: React.FC = () => {
  const { contacts, addContact, updateContact, deleteContact, hasPermission } = useFamily();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingContact, setEditingContact] = useState<ImportantContact | null>(null);
  const [contactToDelete, setContactToDelete] = useState<ImportantContact | null>(null);

  // Form states
  const [formData, setFormData] = useState<{
    name: string;
    category: ContactCategory;
    phone: string;
    alternatePhone: string;
    email: string;
    address: string;
    designationOrSpecialty: string;
    notes: string;
    isQuickDial: boolean;
  }>({
    name: '',
    category: 'Doctors',
    phone: '',
    alternatePhone: '',
    email: '',
    address: '',
    designationOrSpecialty: '',
    notes: '',
    isQuickDial: false,
  });

  const resetForm = () => {
    setFormData({
      name: '',
      category: 'Doctors',
      phone: '',
      alternatePhone: '',
      email: '',
      address: '',
      designationOrSpecialty: '',
      notes: '',
      isQuickDial: false,
    });
    setEditingContact(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setShowAddModal(true);
  };

  const handleOpenEdit = (contact: ImportantContact) => {
    setEditingContact(contact);
    setFormData({
      name: contact.name,
      category: contact.category,
      phone: contact.phone,
      alternatePhone: contact.alternatePhone || '',
      email: contact.email || '',
      address: contact.address || '',
      designationOrSpecialty: contact.designationOrSpecialty || '',
      notes: contact.notes || '',
      isQuickDial: contact.isQuickDial,
    });
    setShowAddModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) return;

    if (editingContact) {
      updateContact(editingContact.id, formData);
    } else {
      addContact(formData);
    }

    setShowAddModal(false);
    resetForm();
  };

  const confirmDelete = () => {
    if (contactToDelete) {
      deleteContact(contactToDelete.id);
      setContactToDelete(null);
    }
  };

  // Filter contacts
  const filteredContacts = contacts.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      (c.designationOrSpecialty && c.designationOrSpecialty.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === 'All' || c.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category: ContactCategory) => {
    switch (category) {
      case 'Ambulance':
      case 'Hospitals':
        return <HeartPulse className="w-4 h-4 text-rose-600" />;
      case 'Doctors':
        return <HeartPulse className="w-4 h-4 text-emerald-600" />;
      case 'Police':
        return <ShieldAlert className="w-4 h-4 text-blue-600" />;
      case 'Bank':
        return <Building2 className="w-4 h-4 text-amber-600" />;
      case 'Emergency Helpline':
        return <LifeBuoy className="w-4 h-4 text-purple-600" />;
      default:
        return <UserCheck className="w-4 h-4 text-indigo-600" />;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <PhoneCall className="w-6 h-6 text-rose-600" />
            <span>Important & Emergency Contacts</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Emergency hotlines (108, 112), family physicians, hospitals, banks and key relatives.
          </p>
        </div>

        {hasPermission('manageContacts') && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Contact</span>
          </button>
        )}
      </div>

      {/* Emergency Quick Dial Strip */}
      <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-rose-950 text-white rounded-3xl p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-300 animate-pulse" />
            <h3 className="font-extrabold text-sm sm:text-base">Government & Rapid Emergency Dials</h3>
          </div>
          <span className="text-[10px] uppercase font-bold bg-white/20 px-2 py-0.5 rounded-full">
            Toll-Free 24x7
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <a
            href="tel:108"
            className="bg-white/10 hover:bg-white/25 p-3 rounded-2xl backdrop-blur-xs transition flex flex-col justify-between active:scale-95"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold">Ambulance</span>
              <HeartPulse className="w-4 h-4 text-rose-300" />
            </div>
            <p className="text-xl font-black font-mono text-amber-300 mt-1">108</p>
          </a>

          <a
            href="tel:112"
            className="bg-white/10 hover:bg-white/25 p-3 rounded-2xl backdrop-blur-xs transition flex flex-col justify-between active:scale-95"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold">Police / ERSS</span>
              <ShieldAlert className="w-4 h-4 text-blue-300" />
            </div>
            <p className="text-xl font-black font-mono text-amber-300 mt-1">112 / 100</p>
          </a>

          <a
            href="tel:101"
            className="bg-white/10 hover:bg-white/25 p-3 rounded-2xl backdrop-blur-xs transition flex flex-col justify-between active:scale-95"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold">Fire Rescue</span>
              <LifeBuoy className="w-4 h-4 text-amber-300" />
            </div>
            <p className="text-xl font-black font-mono text-amber-300 mt-1">101</p>
          </a>

          <a
            href="tel:1091"
            className="bg-white/10 hover:bg-white/25 p-3 rounded-2xl backdrop-blur-xs transition flex flex-col justify-between active:scale-95"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold">Women Helpline</span>
              <UserCheck className="w-4 h-4 text-emerald-300" />
            </div>
            <p className="text-xl font-black font-mono text-amber-300 mt-1">1091</p>
          </a>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setSelectedCategory('All')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
            selectedCategory === 'All'
              ? 'bg-blue-700 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          All Contacts ({contacts.length})
        </button>
        {CONTACT_CATEGORIES.map((cat) => {
          const count = contacts.filter((c) => c.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
                selectedCategory === cat
                  ? 'bg-blue-700 text-white font-bold shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{cat}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    selectedCategory === cat ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by contact name, phone, specialty or category..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
        />
      </div>

      {/* Contacts Cards Grid */}
      {filteredContacts.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <PhoneCall className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No Contacts Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Add your family doctor, nearest hospital, or reliable relatives for quick access in emergency.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredContacts.map((contact) => {
            const cleanPhone = contact.phone.replace(/\D/g, '');

            return (
              <div
                key={contact.id}
                className="bg-white rounded-3xl p-5 border border-slate-200/90 hover:border-blue-500 hover:shadow-xl transition flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* Category Badge & Quick Dial indicator */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg">
                      {getCategoryIcon(contact.category)}
                      <span>{contact.category}</span>
                    </span>

                    <div className="flex items-center gap-1">
                      {hasPermission('manageContacts') && (
                        <>
                          <button
                            onClick={() => handleOpenEdit(contact)}
                            className="p-1 rounded-lg text-slate-400 hover:text-blue-700 hover:bg-blue-50 transition"
                            title="Edit Contact"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setContactToDelete(contact)}
                            className="p-1 rounded-lg text-slate-400 hover:text-rose-700 hover:bg-rose-50 transition"
                            title="Delete Contact"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  <h3 className="font-bold text-sm sm:text-base text-slate-900 leading-tight">
                    {contact.name}
                  </h3>

                  {contact.designationOrSpecialty && (
                    <p className="text-xs text-blue-700 font-semibold mt-0.5">
                      {contact.designationOrSpecialty}
                    </p>
                  )}

                  {/* Contact details */}
                  <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-mono text-slate-800 font-bold">{contact.phone}</span>
                      {contact.alternatePhone && (
                        <span className="text-slate-400 font-mono text-[11px]">/ {contact.alternatePhone}</span>
                      )}
                    </div>

                    {contact.address && (
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="truncate">{contact.address}</span>
                      </div>
                    )}

                    {contact.notes && (
                      <p className="text-[11px] text-slate-400 italic bg-slate-50 p-2 rounded-xl mt-1">
                        "{contact.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Bottom Call & WhatsApp buttons */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <a
                    href={`tel:${contact.phone}`}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white font-bold py-2 rounded-xl text-xs transition active:scale-95 shadow-sm"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Now</span>
                  </a>

                  {contact.phone.length >= 10 && (
                    <a
                      href={`https://wa.me/${cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs transition active:scale-95 shadow-sm"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ADD / EDIT CONTACT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <h3 className="font-bold text-base">
                {editingContact ? 'Edit Contact' : 'Add Important Contact'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Contact Category *
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as ContactCategory })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-bold bg-white"
                >
                  {CONTACT_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Name / Entity Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Dr. Alok Verma, MD or Apollo Hospital"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Designation / Specialty / Relationship
                </label>
                <input
                  type="text"
                  value={formData.designationOrSpecialty}
                  onChange={(e) => setFormData({ ...formData, designationOrSpecialty: e.target.value })}
                  placeholder="e.g. Family Physician, Branch Manager, Chachaji"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Primary Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="108 or +91 98765 43210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Alternate Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.alternatePhone}
                    onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })}
                    placeholder="Landline or emergency mobile"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Clinic / Hospital / Residence Address
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Address or nearest landmark"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Notes / Consultation Hours
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="e.g. Consults morning 9 AM to 2 PM, cashless insurance accepted"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="quickDialCheck"
                  checked={formData.isQuickDial}
                  onChange={(e) => setFormData({ ...formData, isQuickDial: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <label htmlFor="quickDialCheck" className="text-xs font-semibold text-slate-700 cursor-pointer">
                  Show on Dashboard Quick Dial Bar
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  {editingContact ? 'Save Changes' : 'Save Contact'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {contactToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-slate-900 text-base">Remove Contact?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to delete <strong>{contactToDelete.name}</strong> from important contacts?
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setContactToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm"
              >
                Yes, Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
