import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Image as ImageIcon,
  Plus,
  Upload,
  FolderPlus,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Calendar,
  Tag,
  Sparkles,
} from 'lucide-react';
import { GalleryPhoto } from '../types';

export const GalleryView: React.FC = () => {
  const {
    albums,
    photos,
    members,
    addPhoto,
    deletePhoto,
    createAlbum,
    hasPermission,
    currentUser,
  } = useFamily();

  const [selectedAlbum, setSelectedAlbum] = useState<string>('All');
  const [lightboxPhoto, setLightboxPhoto] = useState<GalleryPhoto | null>(null);

  // Modals
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAlbumModal, setShowAlbumModal] = useState(false);
  const [photoToDelete, setPhotoToDelete] = useState<GalleryPhoto | null>(null);

  // Form states
  const [photoForm, setPhotoForm] = useState<{
    album: string;
    caption: string;
    imageUrl: string;
    date: string;
    taggedMemberIds: string[];
  }>({
    album: albums[0]?.name || 'Diwali 2024 Celebration',
    caption: '',
    imageUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=800&auto=format&fit=crop&q=80',
    date: new Date().toISOString().split('T')[0],
    taggedMemberIds: [],
  });

  const [albumForm, setAlbumForm] = useState({
    name: '',
    description: '',
    coverUrl: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600&auto=format&fit=crop&q=80',
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoForm((prev) => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAlbumCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAlbumForm((prev) => ({ ...prev, coverUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreatePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoForm.caption.trim()) return;

    addPhoto({
      ...photoForm,
      uploadedBy: currentUser?.name || 'Family Member',
    });

    setShowUploadModal(false);
    setPhotoForm({
      album: albums[0]?.name || 'General',
      caption: '',
      imageUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=800&auto=format&fit=crop&q=80',
      date: new Date().toISOString().split('T')[0],
      taggedMemberIds: [],
    });
  };

  const handleCreateAlbum = (e: React.FormEvent) => {
    e.preventDefault();
    if (!albumForm.name.trim()) return;

    createAlbum(albumForm.name, albumForm.description, albumForm.coverUrl);
    setShowAlbumModal(false);
    setAlbumForm({
      name: '',
      description: '',
      coverUrl: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600&auto=format&fit=crop&q=80',
    });
  };

  const filteredPhotos =
    selectedAlbum === 'All'
      ? photos
      : photos.filter((p) => p.album === selectedAlbum);

  const confirmDeletePhoto = () => {
    if (photoToDelete) {
      deletePhoto(photoToDelete.id);
      if (lightboxPhoto?.id === photoToDelete.id) {
        setLightboxPhoto(null);
      }
      setPhotoToDelete(null);
    }
  };

  const navigateLightbox = (direction: 'next' | 'prev') => {
    if (!lightboxPhoto) return;
    const currentIndex = filteredPhotos.findIndex((p) => p.id === lightboxPhoto.id);
    if (currentIndex === -1) return;

    if (direction === 'next') {
      const nextIndex = (currentIndex + 1) % filteredPhotos.length;
      setLightboxPhoto(filteredPhotos[nextIndex]);
    } else {
      const prevIndex = (currentIndex - 1 + filteredPhotos.length) % filteredPhotos.length;
      setLightboxPhoto(filteredPhotos[prevIndex]);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-blue-700" />
            <span>Family Photo Gallery & Memories</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Treasured moments, festive celebrations, trips and three generations of love.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {hasPermission('uploadPhotos') && (
            <>
              <button
                onClick={() => setShowAlbumModal(true)}
                className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2.5 rounded-2xl font-bold text-xs shadow-xs transition cursor-pointer"
              >
                <FolderPlus className="w-4 h-4 text-blue-700" />
                <span>New Album</span>
              </button>

              <button
                onClick={() => setShowUploadModal(true)}
                className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Add Photo</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Album Cards Strip */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Family Albums ({albums.length})
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => setSelectedAlbum('All')}
            className={`p-3 rounded-2xl border text-left transition relative overflow-hidden flex flex-col justify-end min-h-[110px] ${
              selectedAlbum === 'All'
                ? 'bg-blue-900 text-white border-blue-700 shadow-md ring-2 ring-blue-600'
                : 'bg-white border-slate-200 text-slate-800 hover:border-blue-400'
            }`}
          >
            <div className="relative z-10">
              <span className="text-[10px] font-bold uppercase tracking-wider opacity-80">
                All Photos
              </span>
              <p className="font-extrabold text-sm sm:text-base leading-tight">Every Memory</p>
              <p className="text-[11px] opacity-75">{photos.length} photos</p>
            </div>
          </button>

          {albums.map((alb) => (
            <div
              key={alb.id}
              onClick={() => setSelectedAlbum(alb.name)}
              className={`p-3 rounded-2xl border text-left transition relative overflow-hidden flex flex-col justify-end min-h-[110px] cursor-pointer group ${
                selectedAlbum === alb.name
                  ? 'border-blue-600 shadow-md ring-2 ring-blue-600'
                  : 'border-slate-200 hover:border-blue-400'
              }`}
            >
              <img
                src={alb.coverUrl}
                alt={alb.name}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/40 to-transparent" />
              <div className="relative z-10 text-white">
                <p className="font-extrabold text-xs sm:text-sm leading-tight truncate">{alb.name}</p>
                <p className="text-[10px] text-slate-300 font-medium">
                  {alb.photoCount} photos
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Photos Grid */}
      {filteredPhotos.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <ImageIcon className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No Photos in this Album</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Upload pictures from Diwali, family vacations, weddings or birthdays to keep them safe.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {filteredPhotos.map((photo) => (
            <div
              key={photo.id}
              onClick={() => setLightboxPhoto(photo)}
              className="bg-white rounded-2xl overflow-hidden border border-slate-200/90 hover:border-blue-500 hover:shadow-lg transition cursor-pointer group flex flex-col"
            >
              <div className="relative aspect-square overflow-hidden bg-slate-100">
                <img
                  src={photo.imageUrl}
                  alt={photo.caption}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <span className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[9px] font-bold px-2 py-0.5 rounded-md">
                  {photo.album}
                </span>
              </div>

              <div className="p-2.5 space-y-1">
                <p className="font-bold text-xs text-slate-900 truncate">{photo.caption}</p>
                <p className="text-[10px] text-slate-400 font-mono">{photo.date}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* LIGHTBOX MODAL */}
      {lightboxPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
          <button
            onClick={() => setLightboxPhoto(null)}
            className="absolute top-4 right-4 rounded-full p-2 bg-white/20 hover:bg-white/40 text-white transition z-10"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Left Arrow */}
          <button
            onClick={() => navigateLightbox('prev')}
            className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full p-2.5 bg-white/15 hover:bg-white/30 text-white transition z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={() => navigateLightbox('next')}
            className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full p-2.5 bg-white/15 hover:bg-white/30 text-white transition z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="max-w-4xl w-full flex flex-col items-center">
            <div className="max-h-[70vh] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={lightboxPhoto.imageUrl}
                alt={lightboxPhoto.caption}
                className="max-h-[70vh] object-contain rounded-2xl"
              />
            </div>

            <div className="mt-4 text-center text-white space-y-1 max-w-xl">
              <span className="text-xs uppercase font-extrabold tracking-wider text-amber-300 bg-white/10 px-3 py-1 rounded-full">
                {lightboxPhoto.album}
              </span>
              <h3 className="font-bold text-base sm:text-lg mt-1">{lightboxPhoto.caption}</h3>
              <p className="text-xs text-slate-300">
                Uploaded by {lightboxPhoto.uploadedBy} on {lightboxPhoto.date}
              </p>

              {/* Tagged members */}
              {lightboxPhoto.taggedMemberIds?.length > 0 && (
                <div className="flex items-center justify-center gap-1.5 flex-wrap pt-2">
                  <Tag className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-xs text-slate-300">With:</span>
                  {lightboxPhoto.taggedMemberIds.map((memId) => {
                    const mem = members.find((m) => m.id === memId);
                    return mem ? (
                      <span
                        key={memId}
                        className="text-[11px] font-semibold bg-white/15 text-white px-2 py-0.5 rounded-full"
                      >
                        {mem.fullName}
                      </span>
                    ) : null;
                  })}
                </div>
              )}

              {/* Action row */}
              <div className="flex items-center justify-center gap-3 pt-3">
                <a
                  href={lightboxPhoto.imageUrl}
                  download="family_memory.jpg"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </a>

                {hasPermission('uploadPhotos') && (
                  <button
                    onClick={() => setPhotoToDelete(lightboxPhoto)}
                    className="flex items-center gap-1 bg-rose-600/80 hover:bg-rose-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* UPLOAD PHOTO MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <h3 className="font-bold text-base">Add Photo to Family Gallery</h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePhoto} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Select Album *
                </label>
                <select
                  value={photoForm.album}
                  onChange={(e) => setPhotoForm({ ...photoForm, album: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-bold"
                >
                  {albums.map((alb) => (
                    <option key={alb.id} value={alb.name}>
                      {alb.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Caption / Memory Story *
                </label>
                <input
                  type="text"
                  required
                  value={photoForm.caption}
                  onChange={(e) => setPhotoForm({ ...photoForm, caption: e.target.value })}
                  placeholder="e.g. Dadaji and Ananya lighting the grand brass diya"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Photo File
                </label>
                <div className="p-4 border-2 border-dashed border-blue-200 rounded-2xl bg-blue-50/50 hover:bg-blue-50 transition text-center cursor-pointer relative">
                  <Upload className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                  <p className="font-bold text-slate-800">Choose Family Photo</p>
                  <p className="text-[10px] text-slate-500">JPG, PNG, WebP supported</p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              </div>

              {/* Tag Members in this photo */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Tag Family Members Present in Photo
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200 max-h-36 overflow-y-auto">
                  {members.map((m) => {
                    const isTagged = photoForm.taggedMemberIds.includes(m.id);
                    return (
                      <label
                        key={m.id}
                        className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-white"
                      >
                        <input
                          type="checkbox"
                          checked={isTagged}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setPhotoForm({
                                ...photoForm,
                                taggedMemberIds: [...photoForm.taggedMemberIds, m.id],
                              });
                            } else {
                              setPhotoForm({
                                ...photoForm,
                                taggedMemberIds: photoForm.taggedMemberIds.filter((id) => id !== m.id),
                              });
                            }
                          }}
                          className="w-3.5 h-3.5 text-blue-600 rounded"
                        />
                        <span className="text-xs text-slate-700 truncate">{m.fullName}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  Upload Memory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE ALBUM MODAL */}
      {showAlbumModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="relative w-full max-w-md rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <h3 className="font-bold text-base">Create New Family Album</h3>
              <button
                onClick={() => setShowAlbumModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAlbum} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Album Title *
                </label>
                <input
                  type="text"
                  required
                  value={albumForm.name}
                  onChange={(e) => setAlbumForm({ ...albumForm, name: e.target.value })}
                  placeholder="e.g. Manali Trip 2025 or Diwali Celebration"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={albumForm.description}
                  onChange={(e) => setAlbumForm({ ...albumForm, description: e.target.value })}
                  placeholder="Tell the family story behind this album..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAlbumModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  Create Album
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE PHOTO */}
      {photoToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-slate-900 text-base">Delete Photo?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to remove this photo from the family album?
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setPhotoToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeletePhoto}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
