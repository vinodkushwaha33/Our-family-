import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  FolderLock,
  Upload,
  Search,
  Filter,
  FileText,
  Eye,
  Download,
  Trash2,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  X,
  FileCheck,
  Shield,
  Clock,
  Sparkles,
} from 'lucide-react';
import { DocumentItem, DocumentCategory } from '../types';

export const DOCUMENT_CATEGORIES: DocumentCategory[] = [
  'Aadhaar Card',
  'PAN Card',
  'Voter ID',
  'Driving License',
  'Passport',
  'Ration Card',
  'Ayushman Card',
  'Bank Documents',
  'Educational Certificates',
  'Birth Certificate',
  'Marriage Certificate',
  'Property Documents',
  'Insurance Documents',
  'Other Documents',
];

export const DocumentLockerView: React.FC = () => {
  const {
    documents,
    members,
    addDocument,
    deleteDocument,
    hasPermission,
    currentUser,
  } = useFamily();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMemberFilter, setSelectedMemberFilter] = useState<string>('All');

  // Modal states
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<DocumentItem | null>(null);
  const [docToDelete, setDocToDelete] = useState<DocumentItem | null>(null);

  // Form states
  const [formData, setFormData] = useState<{
    title: string;
    documentNumber: string;
    category: DocumentCategory;
    memberId: string;
    issueDate: string;
    expiryDate: string;
    notes: string;
    fileUrl: string;
    fileName: string;
    fileSize: string;
    fileType: 'image' | 'pdf' | 'doc';
  }>({
    title: '',
    documentNumber: '',
    category: 'Aadhaar Card',
    memberId: 'family',
    issueDate: '',
    expiryDate: '',
    notes: '',
    fileUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
    fileName: 'document_scan.pdf',
    fileSize: '1.2 MB',
    fileType: 'pdf',
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          fileName: file.name,
          fileSize: `${sizeMb} MB`,
          fileType: isPdf ? 'pdf' : 'image',
          fileUrl: isPdf
            ? 'https://images.unsplash.com/photo-1568667256549-094345857637?w=800&auto=format&fit=crop&q=80'
            : (reader.result as string),
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    const assignedMember =
      formData.memberId === 'family'
        ? 'Entire Family'
        : members.find((m) => m.id === formData.memberId)?.fullName || 'Family Member';

    addDocument({
      ...formData,
      memberName: assignedMember,
      uploadedBy: currentUser?.name || 'Family Admin',
    });

    setShowUploadModal(false);
    setFormData({
      title: '',
      documentNumber: '',
      category: 'Aadhaar Card',
      memberId: 'family',
      issueDate: '',
      expiryDate: '',
      notes: '',
      fileUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
      fileName: 'document_scan.pdf',
      fileSize: '1.2 MB',
      fileType: 'pdf',
    });
  };

  const handleDownload = (doc: DocumentItem) => {
    const a = document.createElement('a');
    a.href = doc.fileUrl;
    a.download = doc.fileName;
    a.target = '_blank';
    a.click();
  };

  const confirmDelete = () => {
    if (docToDelete) {
      deleteDocument(docToDelete.id);
      setDocToDelete(null);
    }
  };

  // Filter documents
  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (doc.documentNumber && doc.documentNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      doc.memberName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === 'All' || doc.category === selectedCategory;

    const matchesMember =
      selectedMemberFilter === 'All' || doc.memberId === selectedMemberFilter;

    return matchesSearch && matchesCategory && matchesMember;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FolderLock className="w-6 h-6 text-blue-700" />
            <span>Digital Document Locker</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Encrypted repository for Aadhaar, PAN, Ayushman, Passports, Land Deeds and Insurance policies.
          </p>
        </div>

        {hasPermission('uploadDocs') && (
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer self-start sm:self-auto"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Document</span>
          </button>
        )}
      </div>

      {/* Category Pills Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCategory('All')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
            selectedCategory === 'All'
              ? 'bg-blue-700 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          All Categories ({documents.length})
        </button>
        {DOCUMENT_CATEGORIES.map((cat) => {
          const count = documents.filter((d) => d.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition flex items-center gap-1.5 ${
                selectedCategory === cat
                  ? 'bg-blue-700 text-white font-bold shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span>{cat}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    selectedCategory === cat ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search and Member Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, document number, or member..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
          />
        </div>

        <select
          value={selectedMemberFilter}
          onChange={(e) => setSelectedMemberFilter(e.target.value)}
          className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
        >
          <option value="All">Filter by Member (All)</option>
          <option value="family">Entire Family Shared</option>
          {members.map((m) => (
            <option key={m.id} value={m.id}>
              {m.fullName} ({m.relationship})
            </option>
          ))}
        </select>
      </div>

      {/* Documents Grid */}
      {filteredDocuments.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No Documents Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            No files match your category or search query. Upload an Aadhaar, PAN or Insurance document to get started.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocuments.map((doc) => {
            const isExpiringSoon =
              doc.expiryDate &&
              (new Date(doc.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24) <= 60;

            return (
              <div
                key={doc.id}
                className="bg-white rounded-3xl p-5 border border-slate-200 hover:border-blue-500 hover:shadow-xl transition flex flex-col justify-between space-y-4 group"
              >
                <div>
                  {/* Top Bar with Category Badge and Verified Pill */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-800 px-2.5 py-1 rounded-lg border border-blue-200/60">
                      {doc.category}
                    </span>

                    {doc.verified && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Verified
                      </span>
                    )}
                  </div>

                  {/* Title & Document Number */}
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 group-hover:text-blue-700 transition">
                    {doc.title}
                  </h3>

                  {doc.documentNumber && (
                    <p className="text-xs font-mono font-bold text-slate-600 mt-0.5">
                      {doc.documentNumber}
                    </p>
                  )}

                  {/* Member attribution */}
                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>Holder:</span>
                    <span className="font-semibold text-slate-800">{doc.memberName}</span>
                  </div>

                  {/* Expiry / Issue Date */}
                  {doc.expiryDate && (
                    <div className="flex items-center justify-between text-xs mt-1">
                      <span className="text-slate-500">Expires:</span>
                      <span
                        className={`font-semibold ${
                          isExpiringSoon ? 'text-rose-600 font-bold flex items-center gap-1' : 'text-slate-800'
                        }`}
                      >
                        {isExpiringSoon && <Clock className="w-3 h-3 text-rose-600 animate-pulse" />}
                        {doc.expiryDate}
                      </span>
                    </div>
                  )}

                  {doc.notes && (
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-2 bg-slate-50 p-2 rounded-xl italic">
                      "{doc.notes}"
                    </p>
                  )}
                </div>

                {/* Bottom Actions */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100 gap-2">
                  <span className="text-[10px] font-mono text-slate-400">
                    {doc.fileSize} • {doc.fileType.toUpperCase()}
                  </span>

                  <div className="flex items-center gap-1">
                    {/* Preview Button */}
                    <button
                      onClick={() => setPreviewDoc(doc)}
                      className="p-2 rounded-xl text-slate-600 hover:text-blue-700 hover:bg-blue-50 transition"
                      title="Preview Document"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {/* Download Button */}
                    {hasPermission('downloadDocs') && (
                      <button
                        onClick={() => handleDownload(doc)}
                        className="p-2 rounded-xl text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition"
                        title="Download Document"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    )}

                    {/* Delete Button */}
                    {hasPermission('deleteDocs') && (
                      <button
                        onClick={() => setDocToDelete(doc)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-700 hover:bg-rose-50 transition"
                        title="Delete Document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* UPLOAD DOCUMENT MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <div className="flex items-center gap-2">
                <FolderLock className="w-5 h-5 text-amber-300" />
                <h3 className="font-bold text-base">Upload to Digital Locker</h3>
              </div>
              <button
                onClick={() => setShowUploadModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              {/* Document Category */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Document Category *
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as DocumentCategory })}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-semibold bg-white"
                >
                  {DOCUMENT_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Title & Document Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Document Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g. Dadaji Ayushman Card"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Document / Card ID No.
                  </label>
                  <input
                    type="text"
                    value={formData.documentNumber}
                    onChange={(e) => setFormData({ ...formData, documentNumber: e.target.value })}
                    placeholder="e.g. •••• •••• 9812 or PAN"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Assign to Member */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Assign To Family Member *
                </label>
                <select
                  value={formData.memberId}
                  onChange={(e) => setFormData({ ...formData, memberId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-medium bg-white"
                >
                  <option value="family">Entire Family Shared</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.relationship})
                    </option>
                  ))}
                </select>
              </div>

              {/* Issue Date & Expiry Date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Issue Date
                  </label>
                  <input
                    type="date"
                    value={formData.issueDate}
                    onChange={(e) => setFormData({ ...formData, issueDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Expiry / Renewal Date
                  </label>
                  <input
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* File Upload Zone */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Document File (PDF or Image)
                </label>
                <div className="p-4 border-2 border-dashed border-blue-200 rounded-2xl bg-blue-50/50 hover:bg-blue-50 transition text-center cursor-pointer relative">
                  <Upload className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                  <p className="font-bold text-slate-800">{formData.fileName}</p>
                  <p className="text-[10px] text-slate-500">
                    Click to select a scanned PDF or photo (Aadhaar/PAN/Policy)
                  </p>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Notes / Verification Remarks
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="e.g. DigiLocker verified, original stored in safe deposit locker #214"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              {/* Footer */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  Save to Locker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DOCUMENT PREVIEW MODAL */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2 truncate">
                <FileText className="w-5 h-5 text-blue-400 shrink-0" />
                <div className="truncate">
                  <h3 className="font-bold text-sm truncate">{previewDoc.title}</h3>
                  <p className="text-[10px] text-slate-400 font-mono truncate">{previewDoc.fileName}</p>
                </div>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="rounded-lg p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Preview Body */}
            <div className="p-6 space-y-4">
              <div className="rounded-2xl overflow-hidden border border-slate-200 max-h-80 flex items-center justify-center bg-slate-100">
                <img
                  src={previewDoc.fileUrl}
                  alt={previewDoc.title}
                  className="w-full h-full object-contain max-h-80"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Category</p>
                  <p className="font-bold text-slate-800">{previewDoc.category}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Card / Doc No.</p>
                  <p className="font-mono font-bold text-slate-800">{previewDoc.documentNumber || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Holder</p>
                  <p className="font-semibold text-slate-800">{previewDoc.memberName}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Expiry</p>
                  <p className="font-semibold text-slate-800">{previewDoc.expiryDate || 'Lifetime / N/A'}</p>
                </div>
              </div>

              {previewDoc.notes && (
                <p className="text-xs text-slate-600 bg-blue-50 p-3 rounded-xl border border-blue-100">
                  <strong>Notes:</strong> {previewDoc.notes}
                </p>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                Uploaded on {new Date(previewDoc.uploadedAt).toLocaleDateString()} by {previewDoc.uploadedBy}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownload(previewDoc)}
                  className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Document</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {docToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-slate-900 text-base">Delete Document?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to delete <strong>{docToDelete.title}</strong>? This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setDocToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
