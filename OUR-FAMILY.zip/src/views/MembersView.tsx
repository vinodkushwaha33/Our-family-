import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  Phone,
  MessageCircle,
  Edit,
  Trash2,
  HeartPulse,
  Calendar,
  MapPin,
  X,
  Upload,
  Check,
  AlertCircle,
} from 'lucide-react';
import { FamilyMember, RelationshipType, BloodGroup } from '../types';
import { DEFAULT_MEMBER_PERMISSIONS } from '../data/mockData';

export const MembersView: React.FC = () => {
  const {
    members,
    addMember,
    updateMember,
    deleteMember,
    setSelectedMemberProfile,
    hasPermission,
    currentUser,
  } = useFamily();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRelationFilter, setSelectedRelationFilter] = useState<string>('All');

  // Modal states
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [memberToDelete, setMemberToDelete] = useState<FamilyMember | null>(null);

  // Form states
  const [formData, setFormData] = useState<{
    fullName: string;
    relationship: RelationshipType;
    dob: string;
    gender: 'Male' | 'Female' | 'Other';
    mobile: string;
    email: string;
    address: string;
    bloodGroup: BloodGroup;
    emergencyContactName: string;
    emergencyContactPhone: string;
    additionalInfo: string;
    avatarUrl: string;
  }>({
    fullName: '',
    relationship: 'Son',
    dob: '',
    gender: 'Male',
    mobile: '',
    email: '',
    address: '',
    bloodGroup: 'B+',
    emergencyContactName: '',
    emergencyContactPhone: '',
    additionalInfo: '',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80',
  });

  const resetForm = () => {
    setFormData({
      fullName: '',
      relationship: 'Son',
      dob: '',
      gender: 'Male',
      mobile: '',
      email: '',
      address: '',
      bloodGroup: 'B+',
      emergencyContactName: '',
      emergencyContactPhone: '',
      additionalInfo: '',
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80',
    });
    setEditingMember(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setShowAddModal(true);
  };

  const handleOpenEdit = (member: FamilyMember, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingMember(member);
    setFormData({
      fullName: member.fullName,
      relationship: member.relationship,
      dob: member.dob,
      gender: member.gender,
      mobile: member.mobile,
      email: member.email || '',
      address: member.address || '',
      bloodGroup: member.bloodGroup,
      emergencyContactName: member.emergencyContactName || '',
      emergencyContactPhone: member.emergencyContactPhone || '',
      additionalInfo: member.additionalInfo || '',
      avatarUrl: member.avatarUrl,
    });
    setShowAddModal(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, avatarUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) return;

    if (editingMember) {
      updateMember(editingMember.id, formData);
    } else {
      addMember({
        ...formData,
        permissions: DEFAULT_MEMBER_PERMISSIONS,
      });
    }

    setShowAddModal(false);
    resetForm();
  };

  const confirmDelete = () => {
    if (memberToDelete) {
      deleteMember(memberToDelete.id);
      setMemberToDelete(null);
    }
  };

  // Filter members
  const filteredMembers = members.filter((m) => {
    const matchesSearch =
      m.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.relationship.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.mobile.includes(searchQuery) ||
      m.bloodGroup.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRelation =
      selectedRelationFilter === 'All' || m.relationship === selectedRelationFilter;

    return matchesSearch && matchesRelation;
  });

  const calculateAge = (dobString: string) => {
    if (!dobString) return '';
    const dob = new Date(dobString);
    const diffMs = Date.now() - dob.getTime();
    const ageDt = new Date(diffMs);
    return Math.abs(ageDt.getUTCFullYear() - 1970);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-700" />
            <span>Family Members Directory</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Manage profiles, health records, relationships, and contacts for every family member.
          </p>
        </div>

        {hasPermission('editOtherProfiles') && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer self-start sm:self-auto"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Family Member</span>
          </button>
        )}
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, relation, mobile or blood group..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
          />
        </div>

        {/* Relationship quick filter */}
        <select
          value={selectedRelationFilter}
          onChange={(e) => setSelectedRelationFilter(e.target.value)}
          className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
        >
          <option value="All">All Relationships ({members.length})</option>
          <option value="Grandfather">Grandfather (Dadaji)</option>
          <option value="Grandmother">Grandmother (Dadiji)</option>
          <option value="Self">Self (Admin)</option>
          <option value="Spouse">Spouse</option>
          <option value="Son">Son</option>
          <option value="Daughter">Daughter</option>
          <option value="Father">Father</option>
          <option value="Mother">Mother</option>
          <option value="Brother">Brother</option>
          <option value="Sister">Sister</option>
          <option value="Uncle">Uncle (Chachaji)</option>
          <option value="Aunt">Aunt (Chachiji)</option>
          <option value="Other">Other Relatives</option>
        </select>
      </div>

      {/* Members Cards Grid */}
      {filteredMembers.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Users className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No Members Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search terms or filter, or add a new family member to your family circle.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.map((member) => {
            const age = calculateAge(member.dob);
            const cleanPhone = member.mobile.replace(/\D/g, '');

            return (
              <div
                key={member.id}
                onClick={() => setSelectedMemberProfile(member)}
                className="bg-white rounded-3xl p-5 border border-slate-200/90 hover:border-blue-500 hover:shadow-xl transition cursor-pointer group flex flex-col justify-between space-y-4 relative"
              >
                {/* Top Info */}
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={member.avatarUrl}
                          alt={member.fullName}
                          className="w-16 h-16 rounded-2xl object-cover ring-2 ring-slate-100 group-hover:ring-blue-600 transition"
                        />
                        <span className="absolute -bottom-1 -right-1 bg-blue-700 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-white">
                          {member.relationship}
                        </span>
                      </div>

                      <div>
                        <h3 className="font-bold text-sm sm:text-base text-slate-900 leading-tight">
                          {member.fullName}
                        </h3>
                        <p className="text-xs text-slate-500 font-medium mt-0.5">
                          {age ? `${age} years` : ''} • {member.gender}
                        </p>
                        {member.bloodGroup && member.bloodGroup !== 'Unknown' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md mt-1 border border-rose-200">
                            <HeartPulse className="w-3 h-3" /> {member.bloodGroup}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions dropdown or buttons */}
                    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      {hasPermission('editOtherProfiles') && (
                        <button
                          onClick={(e) => handleOpenEdit(member, e)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-blue-700 hover:bg-blue-50 transition"
                          title="Edit Member"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      )}
                      {(currentUser?.role === 'admin' || hasPermission('deleteDocs')) && member.relationship !== 'Self' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setMemberToDelete(member);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-700 hover:bg-rose-50 transition"
                          title="Delete Member"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Details snippet */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-mono text-slate-800 font-semibold">{member.mobile}</span>
                    </div>

                    {member.dob && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>DOB: {member.dob}</span>
                      </div>
                    )}

                    {member.address && (
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="truncate">{member.address}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Quick Connect Buttons */}
                <div
                  className="flex items-center gap-2 pt-2"
                  onClick={(e) => e.stopPropagation()}
                >
                  <a
                    href={`tel:${member.mobile}`}
                    className="flex-1 flex items-center justify-center gap-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 font-bold py-2 rounded-xl text-xs transition"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call</span>
                  </a>

                  <a
                    href={`https://wa.me/${cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 flex items-center justify-center gap-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold py-2 rounded-xl text-xs transition"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ADD / EDIT MEMBER MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <h3 className="font-bold text-base">
                {editingMember ? 'Edit Family Member' : 'Add Family Member'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              {/* Photo Upload and Preview */}
              <div className="flex items-center gap-4 pb-3 border-b border-slate-100">
                <img
                  src={formData.avatarUrl}
                  alt="Avatar Preview"
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-600/30"
                />
                <div className="space-y-1">
                  <label className="block font-bold text-slate-700 uppercase tracking-wider text-[10px]">
                    Profile Photo
                  </label>
                  <label className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 px-3 py-1.5 rounded-xl font-bold cursor-pointer transition">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                  <p className="text-[10px] text-slate-400">JPG, PNG supported.</p>
                </div>
              </div>

              {/* Full Name & Relationship */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Rameshwar Sharma"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Relationship *
                  </label>
                  <select
                    value={formData.relationship}
                    onChange={(e) => setFormData({ ...formData, relationship: e.target.value as RelationshipType })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-medium"
                  >
                    <option value="Self">Self (Admin)</option>
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Grandfather">Grandfather (Dadaji)</option>
                    <option value="Grandmother">Grandmother (Dadiji)</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Son">Son</option>
                    <option value="Daughter">Daughter</option>
                    <option value="Brother">Brother</option>
                    <option value="Sister">Sister</option>
                    <option value="Uncle">Uncle (Chachaji)</option>
                    <option value="Aunt">Aunt (Chachiji)</option>
                    <option value="Nephew">Nephew</option>
                    <option value="Niece">Niece</option>
                    <option value="Cousin">Cousin</option>
                    <option value="Other">Other Relative</option>
                  </select>
                </div>
              </div>

              {/* DOB, Gender, Blood Group */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Date of Birth *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.dob}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Gender
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Blood Group
                  </label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-bold text-rose-700"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="Unknown">Unknown</option>
                  </select>
                </div>
              </div>

              {/* Mobile & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Mobile Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@example.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* Residence Address */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Residence Address
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="House No, Street, Colony, City, Pincode"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              {/* Emergency Contact Name & Phone */}
              <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-2xl space-y-2">
                <p className="font-bold text-amber-900 text-xs flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" /> Emergency Contact
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={formData.emergencyContactName}
                    onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                    placeholder="Emergency Contact Name (e.g. Rajesh)"
                    className="w-full px-3 py-2 rounded-xl border border-amber-300/80 bg-white text-slate-800 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <input
                    type="tel"
                    value={formData.emergencyContactPhone}
                    onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                    placeholder="Emergency Phone Number"
                    className="w-full px-3 py-2 rounded-xl border border-amber-300/80 bg-white text-slate-800 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Medical & Additional Info */}
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Medical & Additional Information
                </label>
                <textarea
                  rows={2}
                  value={formData.additionalInfo}
                  onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
                  placeholder="Allergies, chronic conditions, daily medicines or profession..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              {/* Footer Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  {editingMember ? 'Save Changes' : 'Add Member'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {memberToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-slate-900 text-base">Remove Family Member?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to remove <strong>{memberToDelete.fullName}</strong> ({memberToDelete.relationship}) from the family records?
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setMemberToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm"
              >
                Yes, Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
