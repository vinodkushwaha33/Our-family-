import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  BellRing,
  Plus,
  Calendar,
  CheckCircle2,
  Trash2,
  Clock,
  Sparkles,
  Cake,
  Heart,
  Shield,
  FileText,
  X,
  Filter,
} from 'lucide-react';
import { FamilyReminder, ReminderCategory } from '../types';

export const RemindersView: React.FC = () => {
  const {
    allComputedReminders,
    addReminder,
    toggleReminder,
    deleteReminder,
    members,
    hasPermission,
  } = useFamily();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [filterTab, setFilterTab] = useState<'pending' | 'completed' | 'all'>('pending');
  const [showAddModal, setShowAddModal] = useState(false);
  const [reminderToDelete, setReminderToDelete] = useState<FamilyReminder | null>(null);

  const [formData, setFormData] = useState<{
    title: string;
    category: ReminderCategory;
    date: string;
    repeat: 'yearly' | 'monthly' | 'none';
    memberId: string;
    description: string;
  }>({
    title: '',
    category: 'Birthday',
    date: new Date().toISOString().split('T')[0],
    repeat: 'yearly',
    memberId: '',
    description: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    const assignedMember = members.find((m) => m.id === formData.memberId)?.fullName;

    addReminder({
      ...formData,
      memberName: assignedMember,
    });

    setShowAddModal(false);
    setFormData({
      title: '',
      category: 'Birthday',
      date: new Date().toISOString().split('T')[0],
      repeat: 'yearly',
      memberId: '',
      description: '',
    });
  };

  const getDaysLeft = (dateString: string) => {
    const target = new Date(dateString);
    const now = new Date();
    target.setHours(0, 0, 0, 0);
    now.setHours(0, 0, 0, 0);
    const diff = Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return 'Today!';
    if (diff === 1) return 'Tomorrow';
    if (diff < 0) return `${Math.abs(diff)} days passed`;
    return `In ${diff} days`;
  };

  const getCategoryIcon = (category: ReminderCategory) => {
    switch (category) {
      case 'Birthday':
        return <Cake className="w-4 h-4 text-rose-500" />;
      case 'Anniversary':
        return <Heart className="w-4 h-4 text-pink-500" />;
      case 'Insurance Renewal':
        return <Shield className="w-4 h-4 text-amber-500" />;
      case 'Document Expiry':
        return <FileText className="w-4 h-4 text-indigo-500" />;
      default:
        return <Calendar className="w-4 h-4 text-blue-500" />;
    }
  };

  // Filter list
  const filteredReminders = allComputedReminders.filter((rem) => {
    const matchesCategory =
      selectedCategory === 'All' || rem.category === selectedCategory;

    const matchesStatus =
      filterTab === 'all'
        ? true
        : filterTab === 'pending'
        ? !rem.completed
        : rem.completed;

    return matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <BellRing className="w-6 h-6 text-amber-500" />
            <span>Family Reminders & Important Events</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Never miss Dadaji's birthday, health policy renewals, or Aadhaar/PAN expirations.
          </p>
        </div>

        {hasPermission('manageReminders') && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 active:scale-95 text-white px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm shadow-md transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Set Reminder</span>
          </button>
        )}
      </div>

      {/* Filter Tabs & Categories */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Status Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-2xl w-fit text-xs font-bold">
          <button
            onClick={() => setFilterTab('pending')}
            className={`px-3.5 py-1.5 rounded-xl transition ${
              filterTab === 'pending'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Upcoming Active
          </button>
          <button
            onClick={() => setFilterTab('completed')}
            className={`px-3.5 py-1.5 rounded-xl transition ${
              filterTab === 'completed'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3.5 py-1.5 rounded-xl transition ${
              filterTab === 'all'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All ({allComputedReminders.length})
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {['All', 'Birthday', 'Anniversary', 'Insurance Renewal', 'Document Expiry', 'Family Event'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition ${
                selectedCategory === cat
                  ? 'bg-blue-700 text-white font-bold'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Reminders List */}
      {filteredReminders.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <BellRing className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">No Reminders Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            You're all caught up! Add a new reminder for upcoming family celebrations or renewals.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredReminders.map((rem) => {
            const daysLeft = getDaysLeft(rem.date);
            const isDueSoon =
              daysLeft === 'Today!' ||
              daysLeft === 'Tomorrow' ||
              daysLeft.includes('In 1') ||
              daysLeft.includes('In 2') ||
              daysLeft.includes('In 3');

            return (
              <div
                key={rem.id}
                className={`bg-white rounded-3xl p-4 sm:p-5 border transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  rem.completed
                    ? 'border-slate-200 opacity-60 bg-slate-50'
                    : isDueSoon
                    ? 'border-amber-300 shadow-md ring-1 ring-amber-300'
                    : 'border-slate-200/90 hover:border-blue-400'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <input
                    type="checkbox"
                    checked={rem.completed || false}
                    onChange={() => toggleReminder(rem.id)}
                    className="w-5 h-5 text-blue-600 rounded-lg border-slate-300 focus:ring-blue-500 cursor-pointer mt-0.5"
                  />

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="p-1 rounded-lg bg-slate-100">
                        {getCategoryIcon(rem.category)}
                      </span>
                      <h3
                        className={`font-bold text-sm sm:text-base ${
                          rem.completed ? 'line-through text-slate-400' : 'text-slate-900'
                        }`}
                      >
                        {rem.title}
                      </h3>

                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                        {rem.category}
                      </span>

                      {rem.isAutoGenerated && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 flex items-center gap-0.5">
                          <Sparkles className="w-2.5 h-2.5" /> Auto-Synced
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      {rem.description}
                    </p>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2 font-mono">
                      <span>Date: {rem.date}</span>
                      {rem.repeat !== 'none' && <span>• Repeats {rem.repeat}</span>}
                      {rem.memberName && <span>• For: {rem.memberName}</span>}
                    </div>
                  </div>
                </div>

                {/* Right badge & delete */}
                <div className="flex items-center justify-between sm:justify-end gap-3 self-end sm:self-auto shrink-0">
                  <span
                    className={`text-xs font-extrabold px-3 py-1.5 rounded-xl ${
                      isDueSoon
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {daysLeft}
                  </span>

                  {!rem.isAutoGenerated && hasPermission('manageReminders') && (
                    <button
                      onClick={() => setReminderToDelete(rem)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-700 hover:bg-rose-50 transition"
                      title="Delete Reminder"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ADD REMINDER MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="relative w-full max-w-md rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
              <h3 className="font-bold text-base">Create Reminder / Event</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-lg p-1 text-blue-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Reminder Category *
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as ReminderCategory })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none font-bold"
                >
                  <option value="Birthday">Birthday</option>
                  <option value="Anniversary">Anniversary</option>
                  <option value="Insurance Renewal">Insurance Renewal</option>
                  <option value="Document Expiry">Document Expiry</option>
                  <option value="Family Event">Family Event / Festival</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Reminder Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Star Health Premium Payment or Parents Anniversary"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Frequency
                  </label>
                  <select
                    value={formData.repeat}
                    onChange={(e) => setFormData({ ...formData, repeat: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  >
                    <option value="yearly">Repeats Yearly</option>
                    <option value="monthly">Repeats Monthly</option>
                    <option value="none">One Time Only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Assign To Member (Optional)
                </label>
                <select
                  value={formData.memberId}
                  onChange={(e) => setFormData({ ...formData, memberId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  <option value="">General Family</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.relationship})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Description / Action Notes
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="e.g. Order sweets in advance, keep renewal papers ready"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-md transition"
                >
                  Save Reminder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE REMINDER */}
      {reminderToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-bold text-slate-900 text-base">Delete Reminder?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to delete <strong>{reminderToDelete.title}</strong>?
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setReminderToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteReminder(reminderToDelete.id);
                  setReminderToDelete(null);
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
