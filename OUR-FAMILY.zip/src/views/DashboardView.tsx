import React from 'react';
import { useFamily } from '../context/FamilyContext';
import {
  Users,
  FolderLock,
  Image as ImageIcon,
  BellRing,
  PhoneCall,
  ShieldCheck,
  Calendar,
  AlertTriangle,
  ChevronRight,
  Plus,
  HeartPulse,
  Clock,
  Sparkles,
  FileCheck,
  ExternalLink,
} from 'lucide-react';
import { FamilyMember } from '../types';

export const DashboardView: React.FC = () => {
  const {
    currentFamily,
    members,
    documents,
    photos,
    contacts,
    allComputedReminders,
    setActiveTab,
    setSelectedMemberProfile,
    toggleReminder,
    hasPermission,
  } = useFamily();

  // Upcoming reminders
  const upcomingReminders = allComputedReminders.slice(0, 4);

  // Expiring documents (within 60 days)
  const expiringDocs = documents.filter((d) => {
    if (!d.expiryDate) return false;
    const diff = new Date(d.expiryDate).getTime() - Date.now();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days >= 0 && days <= 60;
  });

  const calculateAge = (dobString: string) => {
    if (!dobString) return '';
    const dob = new Date(dobString);
    const diffMs = Date.now() - dob.getTime();
    const ageDt = new Date(diffMs);
    return Math.abs(ageDt.getUTCFullYear() - 1970);
  };

  const getDaysLeft = (dateString: string) => {
    const target = new Date(dateString);
    const now = new Date();
    // Normalize to date only
    target.setHours(0, 0, 0, 0);
    now.setHours(0, 0, 0, 0);
    const diff = Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return 'Today';
    if (diff === 1) return 'Tomorrow';
    if (diff < 0) return `${Math.abs(diff)} days ago`;
    return `In ${diff} days`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white p-6 sm:p-8 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-amber-300 bg-white/10 px-3 py-1 rounded-full backdrop-blur-xs">
              Family Sanctuary
            </span>
            <span className="text-xs text-blue-200">ID: {currentFamily?.familyCode}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
            {currentFamily?.name || 'Sharma Parivar'}
          </h1>

          <p className="text-sm sm:text-base text-blue-100 font-medium mt-2 italic max-w-2xl">
            "{currentFamily?.motto || 'United by Love, Protected by Trust • Vasudhaiva Kutumbakam'}"
          </p>

          {/* Quick Stats Strip */}
          <div className="mt-6 pt-5 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center sm:text-left">
            <div>
              <p className="text-2xl font-black text-white">{members.length}</p>
              <p className="text-xs text-blue-200 font-medium">Family Members</p>
            </div>
            <div>
              <p className="text-2xl font-black text-white">{documents.length}</p>
              <p className="text-xs text-blue-200 font-medium">Locker Documents</p>
            </div>
            <div>
              <p className="text-2xl font-black text-white">{photos.length}</p>
              <p className="text-xs text-blue-200 font-medium">Photo Memories</p>
            </div>
            <div>
              <p className="text-2xl font-black text-white">{allComputedReminders.length}</p>
              <p className="text-xs text-blue-200 font-medium">Tracked Events</p>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Notice / Broadcast Bar if active */}
      {currentFamily?.emergencyNotice && (
        <div className="rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-300 p-4 flex items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500 text-white shrink-0 shadow-xs">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-amber-950">Family Notice & Updates</p>
              <p className="text-amber-900">{currentFamily.emergencyNotice}</p>
            </div>
          </div>
        </div>
      )}

      {/* Expiry Warning Alert if any document expires soon */}
      {expiringDocs.length > 0 && (
        <div className="rounded-2xl bg-rose-50 border border-rose-200 p-4 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <Clock className="w-4 h-4 text-rose-600 shrink-0" />
            <div>
              <span className="font-bold text-rose-900">Document Expiry Alert: </span>
              <span className="text-rose-700">
                {expiringDocs[0].title} expires on {expiringDocs[0].expiryDate}. Keep renewal papers ready!
              </span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('locker')}
            className="font-bold text-rose-800 hover:text-rose-950 underline shrink-0"
          >
            Check Locker
          </button>
        </div>
      )}

      {/* SECTION 1: FAMILY MEMBERS PHOTO CARDS */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-700" />
              <span>Family Members</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                {members.length}
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Click any photo to view complete medical, personal & document profile.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('members')}
            className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 group"
          >
            <span>View All</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition" />
          </button>
        </div>

        {/* Member Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {members.map((member) => {
            const age = calculateAge(member.dob);
            return (
              <div
                key={member.id}
                onClick={() => setSelectedMemberProfile(member)}
                className="bg-white rounded-2xl p-3 border border-slate-200/90 hover:border-blue-500 hover:shadow-lg transition cursor-pointer group flex flex-col items-center text-center relative overflow-hidden"
              >
                {/* Blood Group Badge */}
                {member.bloodGroup && member.bloodGroup !== 'Unknown' && (
                  <span className="absolute top-2 right-2 bg-rose-50 text-rose-700 font-extrabold text-[10px] px-1.5 py-0.5 rounded-md border border-rose-200">
                    {member.bloodGroup}
                  </span>
                )}

                {/* Photo */}
                <div className="relative mt-1 mb-2">
                  <img
                    src={member.avatarUrl}
                    alt={member.fullName}
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover ring-2 ring-slate-100 group-hover:ring-blue-600 transition duration-300"
                  />
                  <span className="absolute -bottom-2 inset-x-0 mx-auto w-fit bg-slate-900/80 backdrop-blur-xs text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                    {member.relationship}
                  </span>
                </div>

                {/* Name */}
                <h3 className="font-bold text-xs sm:text-sm text-slate-900 truncate w-full mt-2">
                  {member.fullName}
                </h3>

                {/* Age & Quick Info */}
                <p className="text-[11px] text-slate-500 font-medium">
                  {age ? `${age} yrs` : member.gender}
                </p>
              </div>
            );
          })}

          {/* Quick Add Member Card */}
          {hasPermission('editOtherProfiles') && (
            <div
              onClick={() => setActiveTab('members')}
              className="bg-blue-50/50 hover:bg-blue-50 rounded-2xl p-4 border-2 border-dashed border-blue-200 hover:border-blue-400 transition cursor-pointer flex flex-col items-center justify-center text-center min-h-[160px] text-blue-700 group"
            >
              <div className="w-12 h-12 rounded-2xl bg-blue-100 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center transition">
                <Plus className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold mt-2">Add Member</span>
            </div>
          )}
        </div>
      </section>

      {/* SECTION 2: TWO COLUMNS (Upcoming Reminders + Quick Locker Shortcuts) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Upcoming Reminders */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BellRing className="w-4 h-4 text-blue-700" />
                <span>Important Family Reminders & Dates</span>
              </h2>
              <p className="text-xs text-slate-500">Birthdays, policy renewals & document alerts</p>
            </div>

            <button
              onClick={() => setActiveTab('reminders')}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
            >
              <span>All Reminders</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2.5">
            {upcomingReminders.map((reminder) => {
              const daysLeft = getDaysLeft(reminder.date);
              const isDueSoon = daysLeft === 'Today' || daysLeft === 'Tomorrow' || daysLeft.includes('In 1') || daysLeft.includes('In 2');

              return (
                <div
                  key={reminder.id}
                  className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                    reminder.completed
                      ? 'bg-slate-50 border-slate-200 opacity-60'
                      : isDueSoon
                      ? 'bg-amber-50/70 border-amber-200'
                      : 'bg-white border-slate-200 hover:border-blue-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={reminder.completed || false}
                      onChange={() => toggleReminder(reminder.id)}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                    />

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`font-bold text-xs sm:text-sm ${reminder.completed ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          {reminder.title}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                          {reminder.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{reminder.description}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`text-xs font-extrabold px-2.5 py-1 rounded-lg ${
                        isDueSoon
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {daysLeft}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-mono">{reminder.date}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Quick Digital Locker Access */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FolderLock className="w-4 h-4 text-blue-700" />
                <span>Digital Locker</span>
              </h2>
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">
                {documents.length} Files
              </span>
            </div>
            <p className="text-xs text-slate-500">Aadhaar, PAN, Ayushman, Insurance & Certificates</p>

            {/* Quick Category Buttons */}
            <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('locker')}
                className="p-3 rounded-2xl bg-blue-50/80 hover:bg-blue-100/80 text-blue-900 border border-blue-200/60 text-left transition"
              >
                <p className="font-extrabold">Aadhaar & PAN</p>
                <p className="text-[10px] text-blue-600 font-normal">Identity Proofs</p>
              </button>

              <button
                onClick={() => setActiveTab('locker')}
                className="p-3 rounded-2xl bg-indigo-50/80 hover:bg-indigo-100/80 text-indigo-900 border border-indigo-200/60 text-left transition"
              >
                <p className="font-extrabold">Ayushman & Health</p>
                <p className="text-[10px] text-indigo-600 font-normal">Medical Cards</p>
              </button>

              <button
                onClick={() => setActiveTab('locker')}
                className="p-3 rounded-2xl bg-amber-50/80 hover:bg-amber-100/80 text-amber-900 border border-amber-200/60 text-left transition"
              >
                <p className="font-extrabold">Insurance Policies</p>
                <p className="text-[10px] text-amber-600 font-normal">Health & Vehicle</p>
              </button>

              <button
                onClick={() => setActiveTab('locker')}
                className="p-3 rounded-2xl bg-emerald-50/80 hover:bg-emerald-100/80 text-emerald-900 border border-emerald-200/60 text-left transition"
              >
                <p className="font-extrabold">Property & Bank</p>
                <p className="text-[10px] text-emerald-600 font-normal">Deeds & Passbooks</p>
              </button>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('locker')}
            className="w-full mt-4 bg-blue-700 hover:bg-blue-800 text-white font-bold py-2.5 rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-sm"
          >
            <span>Open Family Locker</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SECTION 3: RECENT PHOTOS STRIP */}
      <section className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-blue-700" />
              <span>Family Photo Memories</span>
            </h2>
            <p className="text-xs text-slate-500">Shared albums of festivals, trips and family milestones</p>
          </div>

          <button
            onClick={() => setActiveTab('gallery')}
            className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 group"
          >
            <span>View Gallery</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {photos.slice(0, 6).map((photo) => (
            <div
              key={photo.id}
              onClick={() => setActiveTab('gallery')}
              className="group relative rounded-2xl overflow-hidden aspect-square border border-slate-100 shadow-xs cursor-pointer"
            >
              <img
                src={photo.imageUrl}
                alt={photo.caption}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition p-2 flex flex-col justify-end text-white text-[10px]">
                <p className="font-bold truncate">{photo.album}</p>
                <p className="text-slate-300 truncate text-[9px]">{photo.caption}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 4: EMERGENCY QUICK DIALS STRIP */}
      <section className="bg-gradient-to-r from-rose-900 via-rose-800 to-rose-950 text-white rounded-3xl p-5 sm:p-6 shadow-md space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-xs">
              <PhoneCall className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">Emergency Quick Dial Directory</h3>
              <p className="text-xs text-rose-200">Instant one-tap hotline for medical, police & family emergencies</p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('contacts')}
            className="bg-white/20 hover:bg-white/30 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition w-fit"
          >
            All Contacts
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
          {contacts.filter((c) => c.isQuickDial).slice(0, 4).map((con) => (
            <a
              key={con.id}
              href={`tel:${con.phone}`}
              className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl backdrop-blur-xs transition flex items-center justify-between gap-2 active:scale-95"
            >
              <div className="truncate">
                <p className="font-bold text-xs truncate">{con.name}</p>
                <p className="text-[10px] text-rose-200 truncate">{con.category}</p>
              </div>
              <span className="font-mono font-black text-amber-300 text-xs shrink-0">
                {con.phone}
              </span>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
};
