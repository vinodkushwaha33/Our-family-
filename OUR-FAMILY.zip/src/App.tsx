/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FamilyProvider, useFamily } from './context/FamilyContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { DemoModeBanner } from './components/DemoModeBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { MemberProfileModal } from './components/MemberProfileModal';

// Views
import { AuthView } from './views/AuthView';
import { DashboardView } from './views/DashboardView';
import { MembersView } from './views/MembersView';
import { DocumentLockerView } from './views/DocumentLockerView';
import { GalleryView } from './views/GalleryView';
import { ContactsView } from './views/ContactsView';
import { RemindersView } from './views/RemindersView';
import { AdminPanelView } from './views/AdminPanelView';
import { SuperAdminView } from './views/SuperAdminView';
import { X } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentUser, activeTab, selectedMemberProfile, setSelectedMemberProfile } = useFamily();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // If user is not logged in, render the Auth (Phone + OTP) screen
  if (!currentUser) {
    return <AuthView />;
  }

  // Render view by active tab
  const renderCurrentView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'members':
        return <MembersView />;
      case 'locker':
        return <DocumentLockerView />;
      case 'gallery':
        return <GalleryView />;
      case 'contacts':
        return <ContactsView />;
      case 'reminders':
        return <RemindersView />;
      case 'admin':
        return <AdminPanelView />;
      case 'superadmin':
        return <SuperAdminView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Offline Connectivity Notification Banner */}
      <OfflineIndicator />

      {/* Demo Mode / Firebase Status Notification Banner */}
      <DemoModeBanner />

      {/* Main Header */}
      <Header onToggleMobileMenu={() => setMobileSidebarOpen(true)} />

      {/* App Body with Desktop Sidebar + Main Viewport */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex overflow-hidden">
        {/* Desktop Sidebar (hidden on mobile) */}
        <div className="hidden md:block">
          <Sidebar />
        </div>

        {/* Mobile Slide-over Drawer for Sidebar */}
        {mobileSidebarOpen && (
          <div className="fixed inset-0 z-50 flex md:hidden">
            <div
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
              onClick={() => setMobileSidebarOpen(false)}
            />
            <div className="relative w-72 bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-right">
              <div className="p-4 flex items-center justify-between border-b border-slate-100">
                <span className="font-extrabold text-sm text-slate-900">OUR FAMILY Navigation</span>
                <button
                  onClick={() => setMobileSidebarOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                <Sidebar onCloseMobile={() => setMobileSidebarOpen(false)} />
              </div>
            </div>
          </div>
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-12 overflow-y-auto">
          {renderCurrentView()}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (hidden on desktop) */}
      <BottomNav />

      {/* Detailed Member Profile Modal (triggered by clicking member photos) */}
      {selectedMemberProfile && (
        <MemberProfileModal
          onEdit={() => {
            // Closes profile and opens member list
            setSelectedMemberProfile(null);
          }}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <FamilyProvider>
      <MainAppContent />
    </FamilyProvider>
  );
}
