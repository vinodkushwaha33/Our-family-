import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  User,
  Family,
  FamilyMember,
  DocumentItem,
  GalleryPhoto,
  GalleryAlbum,
  ImportantContact,
  FamilyReminder,
  SuperAdminStats,
  MemberPermissions,
  RelationshipType,
  BloodGroup,
  DocumentCategory,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_FAMILY,
  INITIAL_MEMBERS,
  INITIAL_DOCUMENTS,
  INITIAL_ALBUMS,
  INITIAL_PHOTOS,
  INITIAL_CONTACTS,
  INITIAL_REMINDERS,
  INITIAL_SUPER_ADMIN_STATS,
  DEFAULT_MEMBER_PERMISSIONS,
  DEFAULT_ADMIN_PERMISSIONS,
} from '../data/mockData';
import { isFirebaseConfigured, auth, db } from '../lib/firebase';
import { collection, doc, onSnapshot, setDoc, deleteDoc, getDoc, query, where } from 'firebase/firestore';

interface FamilyContextType {
  currentUser: User | null;
  currentFamily: Family | null;
  members: FamilyMember[];
  documents: DocumentItem[];
  albums: GalleryAlbum[];
  photos: GalleryPhoto[];
  contacts: ImportantContact[];
  reminders: FamilyReminder[];
  allComputedReminders: FamilyReminder[];
  superAdminStats: SuperAdminStats;
  isDemoMode: boolean;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedMemberProfile: FamilyMember | null;
  setSelectedMemberProfile: (member: FamilyMember | null) => void;

  // Auth
  loginWithPhone: (phone: string, otp: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  createFamily: (name: string, motto?: string) => Promise<{ success: boolean; familyId?: string; error?: string }>;
  joinFamilyWithCode: (code: string) => Promise<{ success: boolean; error?: string }>;
  switchUserRole: (role: 'admin' | 'member' | 'superadmin') => void;

  // Member CRUD
  addMember: (memberData: Omit<FamilyMember, 'id' | 'familyId' | 'joinedAt'>) => void;
  updateMember: (id: string, updates: Partial<FamilyMember>) => void;
  deleteMember: (id: string) => boolean;

  // Document CRUD
  addDocument: (docData: Omit<DocumentItem, 'id' | 'familyId' | 'uploadedAt'>) => void;
  deleteDocument: (id: string) => boolean;

  // Gallery CRUD
  addPhoto: (photoData: Omit<GalleryPhoto, 'id' | 'familyId'>) => void;
  deletePhoto: (id: string) => boolean;
  createAlbum: (name: string, description: string, coverUrl?: string) => void;

  // Contacts CRUD
  addContact: (contactData: Omit<ImportantContact, 'id' | 'familyId'>) => void;
  updateContact: (id: string, updates: Partial<ImportantContact>) => void;
  deleteContact: (id: string) => void;

  // Reminders CRUD
  addReminder: (reminderData: Omit<FamilyReminder, 'id' | 'familyId'>) => void;
  toggleReminder: (id: string) => void;
  deleteReminder: (id: string) => void;

  // Settings & Permissions
  updateFamilySettings: (updates: Partial<Family>) => void;
  updateMemberPermissions: (memberId: string, permissions: MemberPermissions) => void;
  hasPermission: (permissionKey: keyof MemberPermissions) => boolean;

  // Reset to initial demo data
  resetDemoData: () => void;
}

const FamilyContext = createContext<FamilyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'our_family_user',
  FAMILY: 'our_family_current_family',
  MEMBERS: 'our_family_members',
  DOCUMENTS: 'our_family_documents',
  ALBUMS: 'our_family_albums',
  PHOTOS: 'our_family_photos',
  CONTACTS: 'our_family_contacts',
  REMINDERS: 'our_family_reminders',
};

const CLOUD_COLLECTIONS = ['members', 'documents', 'albums', 'photos', 'contacts', 'reminders'] as const;
const cloudWrite = async (familyId: string, collectionName: string, id: string, data: unknown) => {
  if (!db || !familyId) return;
  try { await setDoc(doc(db, 'families', familyId, collectionName, id), data as Record<string, unknown>); }
  catch (error) { console.error(`Cloud save failed (${collectionName}):`, error); }
};
const cloudDelete = async (familyId: string, collectionName: string, id: string) => {
  if (!db || !familyId) return;
  try { await deleteDoc(doc(db, 'families', familyId, collectionName, id)); }
  catch (error) { console.error(`Cloud delete failed (${collectionName}):`, error); }
};

export const FamilyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDemoMode] = useState<boolean>(!isFirebaseConfigured());

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedMemberProfile, setSelectedMemberProfile] = useState<FamilyMember | null>(null);

  // User state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_USER;
      }
    }
    return INITIAL_USER;
  });

  // Family state
  const [currentFamily, setCurrentFamily] = useState<Family | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FAMILY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_FAMILY;
      }
    }
    return INITIAL_FAMILY;
  });

  // Members state
  const [members, setMembers] = useState<FamilyMember[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_MEMBERS;
      }
    }
    return INITIAL_MEMBERS;
  });

  // Documents state
  const [documents, setDocuments] = useState<DocumentItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_DOCUMENTS;
      }
    }
    return INITIAL_DOCUMENTS;
  });

  // Albums state
  const [albums, setAlbums] = useState<GalleryAlbum[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ALBUMS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_ALBUMS;
      }
    }
    return INITIAL_ALBUMS;
  });

  // Photos state
  const [photos, setPhotos] = useState<GalleryPhoto[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PHOTOS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_PHOTOS;
      }
    }
    return INITIAL_PHOTOS;
  });

  // Contacts state
  const [contacts, setContacts] = useState<ImportantContact[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_CONTACTS;
      }
    }
    return INITIAL_CONTACTS;
  });

  // Reminders state
  const [reminders, setReminders] = useState<FamilyReminder[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REMINDERS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_REMINDERS;
      }
    }
    return INITIAL_REMINDERS;
  });

  const [superAdminStats] = useState<SuperAdminStats>(INITIAL_SUPER_ADMIN_STATS);

  // Persist to localStorage
  useEffect(() => {
    if (currentUser) localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    else localStorage.removeItem(STORAGE_KEYS.USER);
  }, [currentUser]);

  useEffect(() => {
    if (currentFamily) localStorage.setItem(STORAGE_KEYS.FAMILY, JSON.stringify(currentFamily));
    else localStorage.removeItem(STORAGE_KEYS.FAMILY);
  }, [currentFamily]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ALBUMS, JSON.stringify(albums));
  }, [albums]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(photos));
  }, [photos]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(reminders));
  }, [reminders]);

  // Live Firestore sync: each signed-in family device receives the same records.
  useEffect(() => {
    if (!db || !currentFamily?.id) return;
    const familyId = currentFamily.id;
    const setters: Record<string, (items: any[]) => void> = { members: setMembers, documents: setDocuments, albums: setAlbums, photos: setPhotos, contacts: setContacts, reminders: setReminders };
    const unsubscribers = CLOUD_COLLECTIONS.map((name) => onSnapshot(collection(db!, 'families', familyId, name), (snap) => {
      const rows = snap.docs.map((item) => ({ ...item.data(), id: item.id }));
      setters[name](rows);
    }, (error) => console.error(`Firestore listen failed (${name}):`, error)));
    return () => unsubscribers.forEach((unsubscribe) => unsubscribe());
  }, [currentFamily?.id]);

  // Keep family profile in the cloud.
  useEffect(() => {
    if (db && currentFamily?.id) cloudWrite(currentFamily.id, 'meta', 'family', currentFamily);
  }, [currentFamily]);

  // Dynamically compute reminders by synthesizing member birthdays & document expirations
  const allComputedReminders = useMemo(() => {
    const list: FamilyReminder[] = [...reminders];
    const currentYear = new Date().getFullYear();

    // Auto-generate Birthday reminders from member DOB
    members.forEach((m) => {
      if (m.dob) {
        const [, month, day] = m.dob.split('-');
        if (month && day) {
          const birthdayDate = `${currentYear}-${month}-${day}`;
          // Check if already in list
          const exists = list.some(
            (r) => r.category === 'Birthday' && r.memberId === m.id
          );
          if (!exists) {
            list.push({
              id: `auto_bday_${m.id}`,
              familyId: m.familyId,
              title: `${m.fullName}'s Birthday`,
              category: 'Birthday',
              date: birthdayDate,
              repeat: 'yearly',
              memberId: m.id,
              memberName: m.fullName,
              description: `Celebrate ${m.fullName}'s special day (${m.relationship}).`,
              completed: false,
              isAutoGenerated: true,
            });
          }
        }
      }
    });

    // Auto-generate Document Expiry reminders
    documents.forEach((d) => {
      if (d.expiryDate) {
        const exists = list.some(
          (r) => r.category === 'Document Expiry' && r.title.includes(d.title)
        );
        if (!exists) {
          list.push({
            id: `auto_doc_${d.id}`,
            familyId: d.familyId,
            title: `${d.title} Expiration Alert`,
            category: 'Document Expiry',
            date: d.expiryDate,
            repeat: 'none',
            memberId: d.memberId,
            memberName: d.memberName,
            description: `Document "${d.title}" expires on ${d.expiryDate}. Keep renewal papers ready.`,
            completed: false,
            isAutoGenerated: true,
          });
        }
      }
    });

    // Sort by nearest upcoming date
    return list.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [reminders, members, documents]);

  // Permission verification helper
  const hasPermission = (permissionKey: keyof MemberPermissions): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'admin' || currentUser.role === 'superadmin') return true;

    // Check specific member permissions
    const currentMemberRecord = members.find((m) => m.userId === currentUser.id || m.mobile === currentUser.phone);
    if (!currentMemberRecord) return false;

    return Boolean(currentMemberRecord.permissions[permissionKey]);
  };

  // Auth functions
  const loginWithPhone = async (phone: string, otp: string) => {
    // Validate format
    if (!phone || phone.length < 10) {
      return { success: false, error: 'Please enter a valid 10-digit mobile number.' };
    }
    if (otp !== '123456' && otp.length !== 6) {
      return { success: false, error: 'Invalid verification code. For demo mode, enter 123456.' };
    }

    if (isFirebaseConfigured() && !auth?.currentUser) return { success: false, error: 'Phone OTP verification is not complete. Please verify your OTP first.' };

    // Use Firebase UID when real authentication is active.
    const cleanPhone = phone.startsWith('+91') ? phone : `+91 ${phone.replace(/\D/g, '')}`;

    // Check if phone matches Rajesh (admin) or any member
    const existingMember = members.find((m) => m.mobile.replace(/\D/g, '').endsWith(phone.replace(/\D/g, '')));
    
    if (existingMember) {
      const userObj: User = {
        id: auth?.currentUser?.uid || existingMember.userId || `usr_${existingMember.id}`,
        phone: cleanPhone,
        name: existingMember.fullName,
        email: existingMember.email,
        familyId: existingMember.familyId,
        role: existingMember.relationship === 'Self' ? 'admin' : 'member',
        avatarUrl: existingMember.avatarUrl,
      };
      setCurrentUser(userObj);
    } else {
      // New User - default to admin creating or joining
      const userObj: User = {
        id: auth?.currentUser?.uid || `usr_${Date.now()}`,
        phone: cleanPhone,
        name: 'Family Member',
        role: 'admin',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      };
      setCurrentUser(userObj);
    }

    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    if (auth) {
      auth.signOut().catch(() => {});
    }
  };

  const createFamily = async (name: string, motto?: string) => {
    if (!currentUser) return { success: false, error: 'Please log in first' };
    const randomCode = `FAM-${Math.floor(10000 + Math.random() * 90000)}`;
    const newFam: Family = {
      id: `fam_${Date.now()}`,
      familyCode: randomCode,
      name,
      motto: motto || 'Love, Unity, and Trust',
      adminUid: currentUser.id,
      adminName: currentUser.name,
      createdAt: new Date().toISOString(),
      themeColor: 'royal-blue',
      dashboardSections: {
        showEmergencyBar: true,
        showReminders: true,
        showRecentDocs: true,
        showGalleryPreview: true,
        showQuickContacts: true,
      },
    };

    setCurrentFamily(newFam);
    if (db) { try { await setDoc(doc(db, 'families', newFam.id), newFam); } catch (error) { console.error('Family cloud create failed:', error); return { success: false, error: 'Could not save family to cloud. Check Firestore rules.' }; } }
    setCurrentUser({
      ...currentUser,
      familyId: newFam.id,
      role: 'admin',
    });

    // Add creator as first member
    const firstMember: FamilyMember = {
      id: `mem_${Date.now()}`,
      familyId: newFam.id,
      fullName: currentUser.name,
      relationship: 'Self',
      dob: '1985-01-01',
      gender: 'Male',
      mobile: currentUser.phone,
      bloodGroup: 'B+',
      avatarUrl: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
      isRegisteredUser: true,
      userId: currentUser.id,
      permissions: DEFAULT_ADMIN_PERMISSIONS,
      joinedAt: new Date().toISOString(),
    };

    setMembers([firstMember]);
    if (db) await cloudWrite(newFam.id, 'members', firstMember.id, firstMember);
    return { success: true, familyId: newFam.id };
  };

  const joinFamilyWithCode = async (code: string) => {
    const normalized = code.trim().toUpperCase();
    if (!db) {
      if (normalized === currentFamily?.familyCode) return { success: true };
      return { success: false, error: 'Firebase is not configured. Family invite cannot be verified.' };
    }
    try {
      const { getDocs } = await import('firebase/firestore');
      const matches = await getDocs(query(collection(db, 'families'), where('familyCode', '==', normalized)));
      if (matches.empty) return { success: false, error: 'Invalid Family Invite Code. Please request your Family Admin.' };
      const found = matches.docs[0];
      const family = { ...found.data(), id: found.id } as Family;
      setCurrentFamily(family);
      const uid = auth?.currentUser?.uid;
      const joiningUser = currentUser;
      if (uid && joiningUser) {
        const membership = { id: uid, userId: uid, familyId: family.id, fullName: joiningUser.name || 'Family Member', relationship: 'Other', mobile: joiningUser.phone, isRegisteredUser: true, permissions: DEFAULT_MEMBER_PERMISSIONS, joinedAt: new Date().toISOString() };
        await setDoc(doc(db, 'families', family.id, 'members', uid), membership);
        setMembers((prev) => [membership as FamilyMember, ...prev.filter((m) => m.userId !== uid)]);
      }
      setCurrentUser((prev) => prev ? { ...prev, familyId: family.id, role: 'member' } : prev);
      return { success: true };
    } catch (error) { console.error('Join family failed:', error); return { success: false, error: 'Could not join family. Check Firestore rules.' }; }
  };

  const switchUserRole = (role: 'admin' | 'member' | 'superadmin') => {
    if (!currentUser) return;
    setCurrentUser({
      ...currentUser,
      role,
    });
  };

  // Member management
  const addMember = (memberData: Omit<FamilyMember, 'id' | 'familyId' | 'joinedAt'>) => {
    if (!currentFamily) return;
    const newMember: FamilyMember = {
      ...memberData,
      id: `mem_${Date.now()}`,
      familyId: currentFamily.id,
      joinedAt: new Date().toISOString(),
      permissions: memberData.permissions || DEFAULT_MEMBER_PERMISSIONS,
    };
    setMembers((prev) => [newMember, ...prev]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'members', newMember.id, newMember);
  };

  const updateMember = (id: string, updates: Partial<FamilyMember>) => {
    const changed = members.find((m) => m.id === id);
    if (changed && currentFamily) void cloudWrite(currentFamily.id, 'members', id, { ...changed, ...updates });
    setMembers((prev) => prev.map((m) => (m.id === id ? { ...m, ...updates } : m)));
    if (selectedMemberProfile && selectedMemberProfile.id === id) {
      setSelectedMemberProfile((prev) => (prev ? { ...prev, ...updates } : null));
    }
  };

  const deleteMember = (id: string): boolean => {
    if (!hasPermission('editOtherProfiles') && currentUser?.role !== 'admin') {
      return false;
    }
    setMembers((prev) => prev.filter((m) => m.id !== id));
    if (currentFamily) void cloudDelete(currentFamily.id, 'members', id);
    if (selectedMemberProfile?.id === id) {
      setSelectedMemberProfile(null);
    }
    return true;
  };

  // Document management
  const addDocument = (docData: Omit<DocumentItem, 'id' | 'familyId' | 'uploadedAt'>) => {
    if (!currentFamily) return;
    const newDoc: DocumentItem = {
      ...docData,
      id: `doc_${Date.now()}`,
      familyId: currentFamily.id,
      uploadedAt: new Date().toISOString(),
      verified: true,
    };
    setDocuments((prev) => [newDoc, ...prev]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'documents', newDoc.id, newDoc);
  };

  const deleteDocument = (id: string): boolean => {
    if (!hasPermission('deleteDocs')) return false;
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    if (currentFamily) void cloudDelete(currentFamily.id, 'documents', id);
    return true;
  };

  // Gallery management
  const addPhoto = (photoData: Omit<GalleryPhoto, 'id' | 'familyId'>) => {
    if (!currentFamily) return;
    const newPhoto: GalleryPhoto = {
      ...photoData,
      id: `pho_${Date.now()}`,
      familyId: currentFamily.id,
    };
    setPhotos((prev) => [newPhoto, ...prev]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'photos', newPhoto.id, newPhoto);

    // Update album count
    setAlbums((prev) =>
      prev.map((alb) =>
        alb.name === photoData.album
          ? { ...alb, photoCount: alb.photoCount + 1 }
          : alb
      )
    );
  };

  const deletePhoto = (id: string): boolean => {
    if (!hasPermission('uploadPhotos') && currentUser?.role !== 'admin') return false;
    setPhotos((prev) => prev.filter((p) => p.id !== id));
    if (currentFamily) void cloudDelete(currentFamily.id, 'photos', id);
    return true;
  };

  const createAlbum = (name: string, description: string, coverUrl?: string) => {
    const newAlb: GalleryAlbum = {
      id: `alb_${Date.now()}`,
      name,
      description,
      coverUrl: coverUrl || 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=600&auto=format&fit=crop&q=80',
      photoCount: 0,
      createdDate: new Date().toISOString().split('T')[0],
    };
    setAlbums((prev) => [...prev, newAlb]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'albums', newAlb.id, newAlb);
  };

  // Contacts management
  const addContact = (contactData: Omit<ImportantContact, 'id' | 'familyId'>) => {
    if (!currentFamily) return;
    const newContact: ImportantContact = {
      ...contactData,
      id: `con_${Date.now()}`,
      familyId: currentFamily.id,
    };
    setContacts((prev) => [...prev, newContact]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'contacts', newContact.id, newContact);
  };

  const updateContact = (id: string, updates: Partial<ImportantContact>) => {
    const changed = contacts.find((c) => c.id === id);
    if (changed && currentFamily) void cloudWrite(currentFamily.id, 'contacts', id, { ...changed, ...updates });
    setContacts((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
  };

  const deleteContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
    if (currentFamily) void cloudDelete(currentFamily.id, 'contacts', id);
  };

  // Reminders management
  const addReminder = (reminderData: Omit<FamilyReminder, 'id' | 'familyId'>) => {
    if (!currentFamily) return;
    const newRem: FamilyReminder = {
      ...reminderData,
      id: `rem_${Date.now()}`,
      familyId: currentFamily.id,
      completed: false,
    };
    setReminders((prev) => [newRem, ...prev]);
    if (currentFamily) void cloudWrite(currentFamily.id, 'reminders', newRem.id, newRem);
  };

  const toggleReminder = (id: string) => {
    const changed = reminders.find((r) => r.id === id);
    if (changed && currentFamily) void cloudWrite(currentFamily.id, 'reminders', id, { ...changed, completed: !changed.completed });
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, completed: !r.completed } : r)));
  };

  const deleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((r) => r.id !== id));
    if (currentFamily) void cloudDelete(currentFamily.id, 'reminders', id);
  };

  // Settings & Permissions
  const updateFamilySettings = (updates: Partial<Family>) => {
    if (!currentFamily) return;
    const updated = { ...currentFamily, ...updates };
    setCurrentFamily(updated);
  };

  const updateMemberPermissions = (memberId: string, permissions: MemberPermissions) => {
    const changed = members.find((m) => m.id === memberId);
    if (changed && currentFamily) void cloudWrite(currentFamily.id, 'members', memberId, { ...changed, permissions });
    setMembers((prev) => prev.map((m) => (m.id === memberId ? { ...m, permissions } : m)));
  };

  const resetDemoData = () => {
    localStorage.clear();
    setCurrentUser(INITIAL_USER);
    setCurrentFamily(INITIAL_FAMILY);
    setMembers(INITIAL_MEMBERS);
    setDocuments(INITIAL_DOCUMENTS);
    setAlbums(INITIAL_ALBUMS);
    setPhotos(INITIAL_PHOTOS);
    setContacts(INITIAL_CONTACTS);
    setReminders(INITIAL_REMINDERS);
    setActiveTab('dashboard');
  };

  return (
    <FamilyContext.Provider
      value={{
        currentUser,
        currentFamily,
        members,
        documents,
        albums,
        photos,
        contacts,
        reminders,
        allComputedReminders,
        superAdminStats,
        isDemoMode,
        activeTab,
        setActiveTab,
        selectedMemberProfile,
        setSelectedMemberProfile,
        loginWithPhone,
        logout,
        createFamily,
        joinFamilyWithCode,
        switchUserRole,
        addMember,
        updateMember,
        deleteMember,
        addDocument,
        deleteDocument,
        addPhoto,
        deletePhoto,
        createAlbum,
        addContact,
        updateContact,
        deleteContact,
        addReminder,
        toggleReminder,
        deleteReminder,
        updateFamilySettings,
        updateMemberPermissions,
        hasPermission,
        resetDemoData,
      }}
    >
      {children}
    </FamilyContext.Provider>
  );
};

export const useFamily = () => {
  const context = useContext(FamilyContext);
  if (!context) {
    throw new Error('useFamily must be used within a FamilyProvider');
  }
  return context;
};
