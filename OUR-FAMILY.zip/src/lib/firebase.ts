/**
 * Firebase Client Initialization & Utilities
 * Gracefully detects whether real Firebase environment variables are provided.
 */

import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth, RecaptchaVerifier, signInWithPhoneNumber, type ConfirmationResult } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

export function isFirebaseConfigured(): boolean {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey !== 'MY_FIREBASE_API_KEY' &&
    firebaseConfig.apiKey.length > 5
  );
}

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;

if (isFirebaseConfigured()) {
  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    storage = getStorage(app);
    console.log('✅ Firebase initialized successfully with project:', firebaseConfig.projectId);
  } catch (err) {
    console.warn('⚠️ Firebase initialization failed, falling back to Demo Mode:', err);
  }
} else {
  console.info('ℹ️ Firebase credentials not detected in environment variables. Running in Demo Mode.');
}

export { app, auth, db, storage, firebaseConfig };

/**
 * Helper to initialize invisible Recaptcha for phone auth
 */
export function setupRecaptcha(containerId: string): RecaptchaVerifier | null {
  if (!auth) return null;
  try {
    return new RecaptchaVerifier(auth, containerId, {
      size: 'invisible',
      callback: () => {
        // Recaptcha solved
      },
    });
  } catch (error) {
    console.error('Error creating RecaptchaVerifier:', error);
    return null;
  }
}

/**
 * Request OTP via Firebase Phone Auth or Demo Fallback
 */
export async function sendOtpToPhone(
  phoneNumber: string,
  verifier?: RecaptchaVerifier
): Promise<{ success: boolean; confirmationResult?: ConfirmationResult; isDemo: boolean; error?: string }> {
  if (!isFirebaseConfigured() || !auth || !verifier) {
    // In Demo Mode: simulate realistic OTP network latency
    await new Promise((resolve) => setTimeout(resolve, 800));
    return {
      success: true,
      isDemo: true,
    };
  }

  try {
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, verifier);
    return {
      success: true,
      confirmationResult,
      isDemo: false,
    };
  } catch (error: any) {
    console.error('Firebase Phone Auth Error:', error);
    return {
      success: false,
      isDemo: false,
      error: error?.message || 'Failed to send OTP via Firebase.',
    };
  }
}
