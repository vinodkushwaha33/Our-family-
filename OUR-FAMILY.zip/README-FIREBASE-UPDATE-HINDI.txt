OUR FAMILY – FIREBASE UPDATE

Is ZIP mein ye updates shamil hain:
1. AuthView.tsx: Firebase Phone OTP bhejne aur verify karne ka flow (Demo mode mein 123456).
2. FamilyContext.tsx: Members, Documents, Albums, Photos, Contacts aur Reminders ka Firestore live sync.
3. Family create/join ka Firestore integration.
4. Member permissions update ka cloud save.
5. firestore.rules aur storage.rules.

GITHUB PAR UPLOAD:
- Is ZIP ko extract mat kijiye.
- GitHub repository mein purani our-family.zip ko replace karke is ZIP ka naam our-family.zip rakhein.
- GitHub Actions > Build Our Family APK > Run workflow.

FIREBASE CONSOLE PAR ZAROORI:
- Firestore Database > Rules mein is ZIP ki firestore.rules file ka content paste karke Publish karein.
- Storage > Rules mein storage.rules ka content paste karke Publish karein.
- Authentication > Sign-in method mein Phone enabled hona chahiye.
- Authentication > Settings > Authorized domains mein web app ka domain add karein.

IMPORTANT:
- Phone OTP ka real test abhi production device par karna baaki hai. Android WebView/Capacitor par Firebase reCAPTCHA/Phone Auth ke liye native Android SHA-1/SHA-256 aur Firebase Android app setup ki zaroorat pad sakti hai.
- Photo/document file upload ko Storage par migrate karna abhi is update mein include nahi hai; ye update Firestore records/live sync ko connect karta hai. Agar app file ko base64/data URL mein rakhta hai, Firestore document size limit ke karan upload fail ho sakta hai.
- Existing local demo data automatically cloud mein migrate nahi hota. Naya family create/join karke cloud sync test karein.
- Build ko yahan run karke verify nahi kar paya gaya kyunki dependencies install nahi hain/network timeout hua tha. GitHub Actions ka build result check karein.
