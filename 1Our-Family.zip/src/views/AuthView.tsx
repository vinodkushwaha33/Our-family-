import React, { useState } from 'react';
import { useFamily } from '../context/FamilyContext';
import { Shield, Mail, Lock, User, Phone, ArrowRight, Users, Sparkles } from 'lucide-react';

const shell = 'min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 flex items-center justify-center p-4';
const input = 'w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-blue-600';

export const AuthView: React.FC = () => {
  const { authenticateWithEmail, isDemoMode } = useFamily();
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setBusy(true);
    const result = await authenticateWithEmail(email, password, mode, name, phone);
    setBusy(false); if (!result.success) setError(result.error || 'Something went wrong.');
  };
  return <div className={shell}><div className="w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl">
    <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-8 text-center text-white"><div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10"><Shield className="h-8 w-8 text-amber-300" /></div><h1 className="text-2xl font-black">OUR FAMILY</h1><p className="mt-1 text-xs text-blue-200">The Digital Sanctuary for Indian Families</p><p className="mt-3 text-xs text-emerald-200">Secure Email & Password Login · No SMS OTP</p></div>
    <form onSubmit={submit} className="space-y-4 p-6 sm:p-8">
      <div className="flex rounded-xl bg-slate-100 p-1"><button type="button" onClick={()=>{setMode('login');setError('')}} className={`flex-1 rounded-lg py-2 text-sm font-bold ${mode==='login'?'bg-white text-blue-800 shadow':'text-slate-500'}`}>Login</button><button type="button" onClick={()=>{setMode('register');setError('')}} className={`flex-1 rounded-lg py-2 text-sm font-bold ${mode==='register'?'bg-white text-blue-800 shadow':'text-slate-500'}`}>Create Account</button></div>
      {mode==='register' && <><label className="block"><span className="mb-1 block text-xs font-bold text-slate-600">Your Name</span><div className="relative"><User className="absolute left-3 top-3 h-4 w-4 text-slate-400"/><input className={`${input} pl-10`} value={name} onChange={e=>setName(e.target.value)} placeholder="Enter full name" required /></div></label><label className="block"><span className="mb-1 block text-xs font-bold text-slate-600">Mobile Number (optional)</span><div className="relative"><Phone className="absolute left-3 top-3 h-4 w-4 text-slate-400"/><input className={`${input} pl-10`} value={phone} onChange={e=>setPhone(e.target.value)} placeholder="10-digit mobile number" inputMode="numeric" /></div></label></>}
      <label className="block"><span className="mb-1 block text-xs font-bold text-slate-600">Email Address</span><div className="relative"><Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400"/><input className={`${input} pl-10`} type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com" required /></div></label>
      <label className="block"><span className="mb-1 block text-xs font-bold text-slate-600">Password (minimum 6 characters)</span><div className="relative"><Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400"/><input className={`${input} pl-10`} type="password" autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter password" minLength={6} required /></div></label>
      {error && <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700">{error}</div>}
      {isDemoMode && <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800"><Sparkles className="mr-1 inline h-4 w-4"/> Demo mode: accounts are stored only on this device. Firebase credentials are needed for cross-device sync.</div>}
      <button disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-700 py-3.5 text-sm font-bold text-white shadow hover:bg-blue-800 disabled:opacity-50">{busy?'Please wait...':mode==='login'?'Login to Family':'Create Account'} <ArrowRight className="h-4 w-4"/></button>
    </form>
  </div></div>;
};

export const FamilySetupView: React.FC = () => {
  const { currentUser, createFamily, joinFamilyWithCode, logout } = useFamily();
  const [tab,setTab]=useState<'create'|'join'>('create'); const [familyName,setFamilyName]=useState(''); const [motto,setMotto]=useState(''); const [code,setCode]=useState(''); const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  const submit=async(e:React.FormEvent)=>{e.preventDefault();setBusy(true);setError('');const r=tab==='create'?await createFamily(familyName,motto):await joinFamilyWithCode(code);setBusy(false);if(!r.success)setError(r.error||'Could not continue.');};
  return <div className={shell}><div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl"><div className="mb-5 text-center"><Users className="mx-auto mb-2 h-10 w-10 text-blue-700"/><h1 className="text-xl font-black text-slate-900">Set Up Your Family</h1><p className="mt-1 text-xs text-slate-500">Welcome, {currentUser?.name}. Create a family or join with an invite code.</p></div><div className="mb-4 flex rounded-xl bg-slate-100 p-1"><button type="button" onClick={()=>{setTab('create');setError('')}} className={`flex-1 rounded-lg py-2 text-sm font-bold ${tab==='create'?'bg-white text-blue-800 shadow':'text-slate-500'}`}>Create Family</button><button type="button" onClick={()=>{setTab('join');setError('')}} className={`flex-1 rounded-lg py-2 text-sm font-bold ${tab==='join'?'bg-white text-blue-800 shadow':'text-slate-500'}`}>Join Family</button></div><form onSubmit={submit} className="space-y-3">{tab==='create'?<><input className={input} value={familyName} onChange={e=>setFamilyName(e.target.value)} placeholder="Family name" required/><input className={input} value={motto} onChange={e=>setMotto(e.target.value)} placeholder="Family motto (optional)"/></>:<input className={input} value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="FAM-12345" required/>}{error&&<div className="rounded-lg bg-rose-50 p-3 text-xs text-rose-700">{error}</div>}<button disabled={busy} className="w-full rounded-xl bg-blue-700 py-3 font-bold text-white disabled:opacity-50">{busy?'Please wait...':tab==='create'?'Create Family':'Join Family'}</button></form><button onClick={logout} className="mt-4 w-full text-xs font-semibold text-slate-500">Sign out</button></div></div>;
};
