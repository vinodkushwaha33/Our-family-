OUR FAMILY – EMAIL/PASSWORD (NO SMS) UPDATE

WHAT CHANGED
- Phone SMS OTP screen removed.
- Firebase Email/Password account registration and login added.
- New account stores a user profile in Firestore.
- After login, user must create a family or join using a family invite code.
- User's familyId is saved in Firestore user profile for later sign-in.
- Existing Firestore family live-sync code is retained.

FIREBASE CONSOLE – REQUIRED ONE-TIME SETUP
1. Open https://console.firebase.google.com/project/our-family-221c3/authentication/providers
2. Enable Email/Password provider and Save.
3. Keep the project on Spark (no billing upgrade needed for Email/Password Authentication).
4. Firestore Database > Rules: publish the firestore.rules file included in this ZIP.
5. Do NOT enable Phone provider for this app login; it is no longer used.

GITHUB BUILD
- Upload this ZIP to your repository root using the exact filename our-family.zip.
- Workflow should extract it with: unzip -o our-family.zip -d app
- Run GitHub Actions workflow and download OUR-FAMILY-APK artifact.

IMPORTANT LIMITATIONS / HONEST TEST STATUS
- This source archive was updated, but a fresh Android APK build could not be executed in this environment (dependencies/network unavailable). GitHub Actions must pass before installing.
- Email/password login itself does not send SMS and does not require Firebase billing. Other Firebase products/quotas may have separate limits.
- Firestore live sync requires Firestore database and published rules.
- File binary uploads to Firebase Storage are not implemented by this change; this covers Firestore records only. Do not assume photo/document file bytes are cloud-backed yet.
- Existing data stored only in the old app's local storage is not automatically migrated to Firestore.
- If app data from an earlier installation is retained, uninstall/clear app data before first test so old cached login state does not interfere.
