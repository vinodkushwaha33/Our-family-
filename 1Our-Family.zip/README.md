# OUR FAMILY

Updated login: Firebase Email/Password (no SMS OTP). See `README-FIREBASE-UPDATE-HINDI.txt` for setup and deployment steps.

Source archive for GitHub Actions Android APK build. Upload this archive as `our-family.zip` to the repository root.
